<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\Komentar;
use App\Models\Materi;
use Carbon\Carbon;

class SiswaController extends Controller
{
    public function dashboard()
    {
        // Load the student data along with their attendance and grades
        $siswa = Auth::user()->siswa()->with(['kelas'])->first();
        
        $absensis = collect([]);
        $nilais = collect([]);
        $penilaianHarians = collect([]);
        $rekapAbsensiMingguan = [];
        
        if ($siswa) {
            $absensis = $siswa->absensis()->orderBy('tanggal', 'desc')->get();
            $nilais = $siswa->nilais()->get();
            $penilaianHarians = $siswa->penilaianHarians()->orderBy('tanggal', 'desc')->get();

            // Grouping Absensi Per Bulan -> Minggu 1-5
            foreach ($absensis as $absen) {
                $date = \Carbon\Carbon::parse($absen->tanggal);
                $bulanTahun = $date->translatedFormat('F Y');
                $weekNum = min(5, (int)ceil($date->day / 7));
                $mingguKey = 'Minggu ' . $weekNum;

                if (!isset($rekapAbsensiMingguan[$bulanTahun])) {
                    $rekapAbsensiMingguan[$bulanTahun] = [];
                }

                if (!isset($rekapAbsensiMingguan[$bulanTahun][$mingguKey])) {
                    $rekapAbsensiMingguan[$bulanTahun][$mingguKey] = [
                        'H' => 0,
                        'S' => 0,
                        'I' => 0,
                        'A' => 0,
                        'D' => 0,
                        'total' => 0
                    ];
                }

                $st = strtolower(trim($absen->status));
                if ($st === 'hadir') $rekapAbsensiMingguan[$bulanTahun][$mingguKey]['H']++;
                elseif ($st === 'sakit') $rekapAbsensiMingguan[$bulanTahun][$mingguKey]['S']++;
                elseif ($st === 'izin') $rekapAbsensiMingguan[$bulanTahun][$mingguKey]['I']++;
                elseif ($st === 'alpha') $rekapAbsensiMingguan[$bulanTahun][$mingguKey]['A']++;
                elseif ($st === 'dispen') $rekapAbsensiMingguan[$bulanTahun][$mingguKey]['D']++;

                $rekapAbsensiMingguan[$bulanTahun][$mingguKey]['total']++;
            }
        }

        $kkmSetting = \App\Models\Setting::where('key', 'kkm_nilai')->first();
        $kkm = $kkmSetting ? $kkmSetting->value : 75;

        $materis = Materi::orderBy('created_at', 'desc')->get();

        return view('siswa.dashboard', compact('siswa', 'absensis', 'nilais', 'penilaianHarians', 'rekapAbsensiMingguan', 'kkm', 'materis'));
    }

    public function updateProfil(Request $request)
    {
        $user = Auth::user();

        $request->validate([
            'username' => 'required|string|unique:users,username,' . $user->id,
            'password' => 'nullable|string|min:4',
        ]);

        $dataToUpdate = [
            'username' => $request->username,
        ];

        if ($request->filled('password')) {
            $dataToUpdate['password'] = Hash::make($request->password);
        }

        $user->update($dataToUpdate);

        return back()->with('success', 'Profil (Username/Password) berhasil diperbarui!');
    }

    public function storeKomentar(Request $request)
    {
        $request->validate([
            'isi_komentar' => 'required|string|max:300',
        ]);

        $siswa = Auth::user()->siswa;
        if (!$siswa) {
            return back()->withErrors(['Akses ditolak.']);
        }

        $lastKomentar = Komentar::where('siswa_id', $siswa->id)
            ->latest('created_at')
            ->first();

        if ($lastKomentar) {
            $daysDiff = Carbon::parse($lastKomentar->created_at)->diffInDays(Carbon::now());
            if ($daysDiff < 7) {
                return back()->withErrors(['Anda hanya dapat mengirim komentar 1 kali dalam 7 hari.']);
            }
        }

        Komentar::create([
            'siswa_id' => $siswa->id,
            'isi_komentar' => $request->isi_komentar,
            'is_anonim' => $request->has('is_anonim') ? true : false,
        ]);

        return back()->with('success', 'Komentar berhasil dikirim dan akan tampil di halaman utama!');
    }
}
