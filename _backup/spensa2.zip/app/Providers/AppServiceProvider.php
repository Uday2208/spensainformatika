<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        if (!app()->runningInConsole()) {
            \Illuminate\Support\Facades\View::composer('*', function ($view) {
                try {
                    $settings = \App\Models\Setting::pluck('value', 'key')->toArray();
                    $view->with('app_settings', $settings);
                } catch (\Exception $e) {
                    $view->with('app_settings', []);
                }
            });
        }
    }
}
