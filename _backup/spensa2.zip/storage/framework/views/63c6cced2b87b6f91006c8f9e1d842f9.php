<div <?php echo e($attributes->merge(['class' => "h-0 w-full relative"])); ?>>
    <div class="absolute top-[-1px] left-0 right-0 bottom-0 border-t border-dashed border-neutral-300 dark:border-white/[9%]"></div>
</div>
<?php /**PATH /home/vol3_7/infinityfree.com/if0_42547424/htdocs/vendor/laravel/framework/src/Illuminate/Foundation/Providers/../resources/exceptions/renderer/components/separator.blade.php ENDPATH**/ ?>