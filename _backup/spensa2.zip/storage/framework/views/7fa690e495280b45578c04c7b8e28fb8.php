<?php $__env->startSection('title', 'Input Nilai'); ?>
<?php $__env->startSection('page_title', 'Input Nilai Siswa'); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<div class="mb-4 bg-green-100 text-green-800 p-3 rounded text-sm border border-green-200">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<div x-data="{ tab: 'input', pHarian: 20, pTugas: 30, pQuiz: 30, pProyek: 20, useHarian: true, useTugas: true, useQuiz: true, useProyek: true, editModalOpen: false, kkmModalOpen: false, editData: { id: '', bab: '', tugas: '', quiz: '', proyek: '' } }">
    
    <!-- Tabs -->
    <div class="flex flex-col sm:flex-row justify-between mb-4 border-b border-slate-200">
        <div class="flex overflow-x-auto">
            <button @click="tab = 'input'" :class="tab === 'input' ? 'bg-white border-t-2 border-l border-r border-blue-600 text-blue-700 font-bold shadow-sm' : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-transparent'" class="px-5 py-3 text-sm transition-colors border-t-2 rounded-t mr-1 whitespace-nowrap">
                Input Nilai Baru
            </button>
            <button @click="tab = 'riwayat'" :class="tab === 'riwayat' ? 'bg-white border-t-2 border-l border-r border-blue-600 text-blue-700 font-bold shadow-sm' : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-transparent'" class="px-5 py-3 text-sm transition-colors border-t-2 rounded-t mr-1 whitespace-nowrap">
                Riwayat & Edit Nilai
            </button>
            <button @click="tab = 'rekap'" :class="tab === 'rekap' ? 'bg-white border-t-2 border-l border-r border-blue-600 text-blue-700 font-bold shadow-sm' : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-transparent'" class="px-5 py-3 text-sm transition-colors border-t-2 rounded-t whitespace-nowrap">
                Rekap Semester
            </button>
        </div>
        <div class="py-2 sm:py-0 flex items-center">
            <button @click="kkmModalOpen = true" class="btn-compact bg-amber-100 text-amber-700 hover:bg-amber-200 border border-amber-300 shadow-sm flex items-center text-xs">
                <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                Atur KKM (<?php echo e($kkm); ?>)
            </button>
        </div>
    </div>

    <!-- Tab Input -->
    <div x-show="tab === 'input'" class="bg-white rounded-b rounded-tr border border-slate-200 shadow-sm p-4">
    <form action="<?php echo e(url('/app/nilai')); ?>" method="POST" id="nilaiForm">
        <?php echo csrf_field(); ?>
        
        <!-- Controls -->
        <div class="flex flex-col lg:flex-row lg:items-end justify-between mb-4 pb-4 border-b border-slate-100 gap-4">
            <div class="flex flex-col md:flex-row items-start md:items-end space-y-3 md:space-y-0 md:space-x-4">
                <div>
                    <label class="block text-xs font-semibold text-slate-500 mb-1">Materi / Bab</label>
                    <div class="flex items-center space-x-2">
                        <input type="text" name="bab" id="inputBabUtama" list="daftarBabList" required placeholder="Contoh: Bab 1 - Aljabar" class="input-compact bg-slate-50 w-full md:w-48">
                        <button type="button" onclick="loadExistingGrades()" class="btn-compact bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs whitespace-nowrap" title="Muat nilai sebelumnya jika bab sudah ada">Muat Data</button>
                    </div>
                    <datalist id="daftarBabList">
                        <?php $__currentLoopData = $daftar_bab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($bab); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </datalist>
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-500 mb-1">Filter Kelas</label>
                    <select id="kelasFilter" onchange="filterKelas()" class="input-compact bg-slate-50 w-full md:w-32 cursor-pointer">
                        <option value="all">Semua Kelas</option>
                        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k->id); ?>"><?php echo e($k->nama_kelas); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                
                <!-- Bobot Persentase dengan Ceklis Dinamis -->
                <div class="flex space-x-2 bg-blue-50 p-1.5 rounded border border-blue-100">
                    <div class="flex flex-col items-center">
                        <label class="flex items-center gap-1 cursor-pointer mb-1" title="Centang untuk mengaktifkan Penilaian Harian">
                            <input type="checkbox" x-model="useHarian" @change="if(!useHarian) { pHarian = 0; }" class="w-3 h-3 text-blue-600 rounded focus:ring-blue-500 cursor-pointer">
                            <span class="text-[10px] font-bold text-blue-800">Harian (%)</span>
                        </label>
                        <input type="number" name="p_harian" x-model.number="pHarian" min="0" max="100" x-show="useHarian" :disabled="!useHarian" class="input-compact w-16 text-center text-xs">
                        <input type="hidden" name="p_harian" value="0" :disabled="useHarian">
                    </div>
                    <div class="flex flex-col items-center">
                        <label class="flex items-center gap-1 cursor-pointer mb-1" title="Centang untuk mengaktifkan nilai Tugas">
                            <input type="checkbox" x-model="useTugas" @change="if(!useTugas) { pTugas = 0; document.querySelectorAll('.input-tugas').forEach(el => el.value = 0) }" class="w-3 h-3 text-blue-600 rounded focus:ring-blue-500 cursor-pointer">
                            <span class="text-[10px] font-bold text-blue-800">Tugas (%)</span>
                        </label>
                        <input type="number" name="p_tugas" x-model.number="pTugas" min="0" max="100" x-show="useTugas" :disabled="!useTugas" class="input-compact w-16 text-center text-xs">
                        <input type="hidden" name="p_tugas" value="0" :disabled="useTugas">
                    </div>
                    <div class="flex flex-col items-center">
                        <label class="flex items-center gap-1 cursor-pointer mb-1" title="Centang untuk mengaktifkan nilai Quiz">
                            <input type="checkbox" x-model="useQuiz" @change="if(!useQuiz) { pQuiz = 0; document.querySelectorAll('.input-quiz').forEach(el => el.value = 0) }" class="w-3 h-3 text-blue-600 rounded focus:ring-blue-500 cursor-pointer">
                            <span class="text-[10px] font-bold text-blue-800">Quiz (%)</span>
                        </label>
                        <input type="number" name="p_quiz" x-model.number="pQuiz" min="0" max="100" x-show="useQuiz" :disabled="!useQuiz" class="input-compact w-16 text-center text-xs">
                        <input type="hidden" name="p_quiz" value="0" :disabled="useQuiz">
                    </div>
                    <div class="flex flex-col items-center">
                        <label class="flex items-center gap-1 cursor-pointer mb-1" title="Centang untuk mengaktifkan nilai Proyek">
                            <input type="checkbox" x-model="useProyek" @change="if(!useProyek) { pProyek = 0; document.querySelectorAll('.input-proyek').forEach(el => el.value = 0) }" class="w-3 h-3 text-blue-600 rounded focus:ring-blue-500 cursor-pointer">
                            <span class="text-[10px] font-bold text-blue-800">Proyek (%)</span>
                        </label>
                        <input type="number" name="p_proyek" x-model.number="pProyek" min="0" max="100" x-show="useProyek" :disabled="!useProyek" class="input-compact w-16 text-center text-xs">
                        <input type="hidden" name="p_proyek" value="0" :disabled="useProyek">
                    </div>
                </div>
            </div>
            
            <div class="mt-2 lg:mt-0">
                <button type="submit" :disabled="(pHarian + pTugas + pQuiz + pProyek) !== 100" 
                        :class="(pHarian + pTugas + pQuiz + pProyek) !== 100 ? 'bg-slate-400 border-slate-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700 border-blue-700'" 
                        class="btn-compact w-full lg:w-auto text-white border shadow-sm transition-colors">
                    Simpan Nilai
                </button>
            </div>
        </div>

        <!-- Info Formula -->
        <div class="mb-3 text-xs flex justify-between items-center" :class="(pHarian + pTugas + pQuiz + pProyek) === 100 ? 'text-slate-500' : 'text-red-600 font-bold'">
            <span class="italic">* Rumus: (Rata2 Harian × <span x-text="pHarian"></span>%) + (Tugas × <span x-text="pTugas"></span>%) + (Quiz × <span x-text="pQuiz"></span>%) + (Proyek × <span x-text="pProyek"></span>%)</span>
            <span x-show="(pHarian + pTugas + pQuiz + pProyek) !== 100">Peringatan: Total persentase saat ini adalah <span x-text="pHarian + pTugas + pQuiz + pProyek"></span>% (Seharusnya 100%)</span>
        </div>

        <!-- Compact Table -->
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse table-compact">
                <thead>
                    <tr>
                        <th class="w-10 text-center">No</th>
                        <th>Nomer Induk</th>
                        <th>Nama Siswa</th>
                        <th>Kelas</th>
                        <th class="w-24 text-center" x-show="useTugas">Tugas</th>
                        <th class="w-24 text-center" x-show="useQuiz">Quiz</th>
                        <th class="w-24 text-center" x-show="useProyek">Proyek</th>
                        <th class="w-24 text-center bg-blue-50">Nilai Akhir</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-slate-50 siswa-row" data-kelas="<?php echo e($siswa->kelas_id); ?>" data-siswa="<?php echo e($siswa->id); ?>" x-data="{ tugas: 0, quiz: 0, proyek: 0 }">
                        <td class="text-center text-slate-500"><?php echo e($index + 1); ?></td>
                        <td class="font-mono text-slate-600"><?php echo e($siswa->nis); ?></td>
                        <td class="font-medium text-slate-800"><?php echo e($siswa->user->name ?? '-'); ?></td>
                        <td class="text-slate-600"><?php echo e($siswa->kelas->nama_kelas ?? '-'); ?></td>
                        <td class="p-1" x-show="useTugas">
                            <input type="number" x-model.number="tugas" name="nilai[<?php echo e($siswa->id); ?>][tugas]" min="0" max="100" class="input-compact input-tugas w-full text-center bg-white" placeholder="0">
                        </td>
                        <td class="p-1" x-show="useQuiz">
                            <input type="number" x-model.number="quiz" name="nilai[<?php echo e($siswa->id); ?>][quiz]" min="0" max="100" class="input-compact input-quiz w-full text-center bg-white" placeholder="0">
                        </td>
                        <td class="p-1" x-show="useProyek">
                            <input type="number" x-model.number="proyek" name="nilai[<?php echo e($siswa->id); ?>][proyek]" min="0" max="100" class="input-compact input-proyek w-full text-center bg-white" placeholder="0">
                        </td>
                        <td class="p-1" :class="((80 * (pHarian/100)) + (tugas * (pTugas/100)) + (quiz * (pQuiz/100)) + (proyek * (pProyek/100))) < <?php echo e($kkm); ?> ? 'bg-red-50/50' : 'bg-blue-50/50'">
                            <div class="w-full text-center font-bold py-1" 
                                 title="Prediksi Nilai Akhir (Asumsi Rata-rata harian 80)"
                                 :class="((80 * (pHarian/100)) + (tugas * (pTugas/100)) + (quiz * (pQuiz/100)) + (proyek * (pProyek/100))) < <?php echo e($kkm); ?> ? 'text-red-600' : 'text-blue-700'"
                                 x-text="((80 * (pHarian/100)) + (tugas * (pTugas/100)) + (quiz * (pQuiz/100)) + (proyek * (pProyek/100))).toFixed(1)">0.0</div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center py-4 text-slate-500 italic">Belum ada data siswa terdaftar.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </form>
    </div>

    <!-- Tab Riwayat -->
    <div x-show="tab === 'riwayat'" x-cloak class="bg-white rounded-b rounded-tr border border-slate-200 shadow-sm p-4">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 gap-3">
            <h3 class="font-bold text-slate-700 text-sm">Semua Riwayat Nilai</h3>
            
            <!-- Filters -->
            <div class="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3 w-full md:w-auto">
                <select id="filterRiwayatBab" onchange="filterRiwayat()" class="input-compact bg-slate-50 w-full sm:w-48 cursor-pointer">
                    <option value="all">Semua Materi / Bab</option>
                    <?php $__currentLoopData = $daftar_bab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e(strtolower($bab)); ?>"><?php echo e($bab); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                
                <select id="filterRiwayatKelas" onchange="filterRiwayat()" class="input-compact bg-slate-50 w-full sm:w-32 cursor-pointer">
                    <option value="all">Semua Kelas</option>
                    <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k->id); ?>"><?php echo e($k->nama_kelas); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <?php if($riwayat_nilai->isEmpty()): ?>
        <div class="border border-dashed border-slate-300 p-8 rounded text-center text-slate-500 text-sm">
            Belum ada riwayat nilai yang diinput.
        </div>
        <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse table-compact">
                <thead>
                    <tr>
                        <th class="w-10 text-center">No</th>
                        <th>Tanggal Input</th>
                        <th>Siswa</th>
                        <th>Kelas</th>
                        <th>Bab / Materi</th>
                        <th class="text-center">Tugas</th>
                        <th class="text-center">Quiz</th>
                        <th class="text-center">Proyek</th>
                        <th class="text-center bg-blue-50">Nilai Akhir</th>
                        <th class="text-center w-24">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $riwayat_nilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $rn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-slate-50 riwayat-row" data-kelas="<?php echo e($rn->siswa->kelas_id); ?>" data-bab="<?php echo e(strtolower($rn->bab)); ?>">
                        <td class="text-center text-slate-500"><?php echo e($index + 1); ?></td>
                        <td class="text-slate-600 text-xs"><?php echo e($rn->created_at->format('d M Y H:i')); ?></td>
                        <td class="font-medium text-slate-800"><?php echo e($rn->siswa->user->name ?? '-'); ?></td>
                        <td class="text-slate-600"><?php echo e($rn->siswa->kelas->nama_kelas ?? '-'); ?></td>
                        <td class="font-bold text-slate-700"><?php echo e($rn->bab); ?></td>
                        <td class="text-center <?php echo e($rn->tugas < $kkm ? 'text-red-600 font-bold' : ''); ?>"><?php echo e($rn->tugas); ?></td>
                        <td class="text-center <?php echo e($rn->quiz < $kkm ? 'text-red-600 font-bold' : ''); ?>"><?php echo e($rn->quiz); ?></td>
                        <td class="text-center <?php echo e($rn->proyek < $kkm ? 'text-red-600 font-bold' : ''); ?>"><?php echo e($rn->proyek); ?></td>
                        <td class="text-center font-bold <?php echo e($rn->nilai_akhir < $kkm ? 'text-red-700 bg-red-50' : 'text-slate-800 bg-slate-50/50'); ?>"><?php echo e($rn->nilai_akhir); ?></td>
                        <td class="text-center">
                            <div class="flex items-center justify-center space-x-1">
                                <button type="button" 
                                    @click="editData = { id: '<?php echo e($rn->id); ?>', bab: '<?php echo e(addslashes($rn->bab)); ?>', tugas: '<?php echo e($rn->tugas); ?>', quiz: '<?php echo e($rn->quiz); ?>', proyek: '<?php echo e($rn->proyek); ?>' }; editModalOpen = true" 
                                    class="text-blue-500 hover:text-blue-700 hover:bg-blue-50 p-1 rounded" title="Ubah">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path></svg>
                                </button>
                                <form action="<?php echo e(url('/app/nilai', $rn->id)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus nilai ini?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-500 hover:text-red-700 hover:bg-red-50 p-1 rounded" title="Hapus">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>

    <!-- Tab Rekap Semester -->
    <div x-show="tab === 'rekap'" x-cloak class="bg-white rounded-b rounded-tr border border-slate-200 shadow-sm p-4">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 gap-3">
            <div>
                <h3 class="font-bold text-slate-700 text-sm">Rekapitulasi Nilai Akhir Semester</h3>
                <p class="text-xs text-slate-500 mt-1">Rata-rata dari seluruh materi/bab yang telah dinilai.</p>
            </div>
            
            <div class="w-full md:w-auto">
                <select id="filterRekapKelas" onchange="filterRekap()" class="input-compact bg-slate-50 w-full md:w-48 cursor-pointer">
                    <option value="all">Semua Kelas</option>
                    <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k->id); ?>"><?php echo e($k->nama_kelas); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse table-compact">
                <thead>
                    <tr>
                        <th class="w-10 text-center">No</th>
                        <th>Nomer Induk</th>
                        <th>Nama Siswa</th>
                        <th>Kelas</th>
                        <th class="text-center">Total Bab</th>
                        <th class="text-center bg-blue-50 w-32">Rata-rata Rapor</th>
                        <th class="text-center w-24">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $total_bab = $siswa->nilais->count();
                            $rata_rata = $total_bab > 0 ? round($siswa->nilais->avg('nilai_akhir'), 1) : 0;
                            $lulus = $rata_rata >= $kkm;
                        ?>
                        <tr class="hover:bg-slate-50 rekap-row" data-kelas="<?php echo e($siswa->kelas_id); ?>">
                            <td class="text-center text-slate-500"><?php echo e($index + 1); ?></td>
                            <td class="font-mono text-slate-600"><?php echo e($siswa->nis); ?></td>
                            <td class="font-medium text-slate-800"><?php echo e($siswa->user->name ?? '-'); ?></td>
                            <td class="text-slate-600"><?php echo e($siswa->kelas->nama_kelas ?? '-'); ?></td>
                            <td class="text-center font-medium"><?php echo e($total_bab); ?></td>
                            <td class="text-center font-bold text-lg <?php echo e($rata_rata < $kkm && $total_bab > 0 ? 'text-red-600 bg-red-50/50' : ($total_bab > 0 ? 'text-blue-700 bg-blue-50/50' : 'text-slate-400')); ?>">
                                <?php echo e($total_bab > 0 ? $rata_rata : '-'); ?>

                            </td>
                            <td class="text-center">
                                <?php if($total_bab == 0): ?>
                                    <span class="text-xs text-slate-400 italic">Belum dinilai</span>
                                <?php elseif($lulus): ?>
                                    <span class="inline-block px-2 py-1 bg-green-100 text-green-800 text-[10px] font-bold rounded">TUNTAS</span>
                                <?php else: ?>
                                    <span class="inline-block px-2 py-1 bg-red-100 text-red-800 text-[10px] font-bold rounded">TDK TUNTAS</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Edit Modal -->
    <div x-show="editModalOpen" style="display: none;" class="fixed inset-0 z-50 overflow-y-auto bg-black bg-opacity-50 flex items-center justify-center">
        <div class="bg-white rounded p-6 shadow-xl w-full max-w-md mx-4" @click.away="editModalOpen = false">
            <h3 class="font-bold text-slate-800 text-lg mb-4">Ubah Nilai Siswa</h3>
            <form :action="`<?php echo e(url('/app/nilai')); ?>/${editData.id}`" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                
                <!-- Send percentages so backend can recalculate properly -->
                <input type="hidden" name="p_harian" :value="pHarian">
                <input type="hidden" name="p_tugas" :value="pTugas">
                <input type="hidden" name="p_quiz" :value="pQuiz">
                <input type="hidden" name="p_proyek" :value="pProyek">

                <div class="mb-3">
                    <label class="block text-xs font-semibold text-slate-600 mb-1">Materi / Bab</label>
                    <input type="text" name="bab" x-model="editData.bab" required class="input-compact w-full bg-slate-50">
                </div>
                
                <div class="grid grid-cols-3 gap-3 mb-4">
                    <div>
                        <label class="block text-xs font-semibold text-slate-600 mb-1">Tugas</label>
                        <input type="number" name="tugas" x-model.number="editData.tugas" min="0" max="100" required class="input-compact w-full bg-slate-50 text-center">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-600 mb-1">Quiz</label>
                        <input type="number" name="quiz" x-model.number="editData.quiz" min="0" max="100" required class="input-compact w-full bg-slate-50 text-center">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-600 mb-1">Proyek</label>
                        <input type="number" name="proyek" x-model.number="editData.proyek" min="0" max="100" required class="input-compact w-full bg-slate-50 text-center">
                    </div>
                </div>

                <div class="mb-4 text-xs text-blue-700 bg-blue-50 p-2 rounded flex justify-between items-center">
                    <span title="Prediksi Nilai Akhir (Asumsi Rata-rata Harian 80)">Prediksi Nilai Akhir:</span>
                    <strong x-text="((80 * (pHarian/100)) + (editData.tugas * (pTugas/100)) + (editData.quiz * (pQuiz/100)) + (editData.proyek * (pProyek/100))).toFixed(1)"></strong>
                </div>
                
                <div class="flex justify-end gap-2">
                    <button type="button" @click="editModalOpen = false" class="btn-compact bg-slate-200 hover:bg-slate-300 text-slate-700">Batal</button>
                    <button type="submit" class="btn-compact bg-blue-600 hover:bg-blue-700 text-white shadow-sm">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>

    <!-- KKM Modal -->
    <div x-show="kkmModalOpen" style="display: none;" class="fixed inset-0 z-50 overflow-y-auto bg-black bg-opacity-50 flex items-center justify-center">
        <div class="bg-white rounded p-6 shadow-xl w-full max-w-sm mx-4" @click.away="kkmModalOpen = false">
            <h3 class="font-bold text-slate-800 text-lg mb-2">Pengaturan KKM</h3>
            <p class="text-xs text-slate-500 mb-4">Kriteria Ketuntasan Minimal akan digunakan untuk menentukan batas lulus nilai siswa pada tabel nilai dan rapor.</p>
            
            <form action="<?php echo e(url('/app/setting-kkm')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-4">
                    <label class="block text-sm font-semibold text-slate-700 mb-2">Batas Nilai KKM</label>
                    <input type="number" name="kkm" value="<?php echo e($kkm); ?>" min="0" max="100" required class="input-compact w-full text-lg p-2 font-bold text-center">
                </div>
                
                <div class="flex justify-end gap-2">
                    <button type="button" @click="kkmModalOpen = false" class="btn-compact bg-slate-200 hover:bg-slate-300 text-slate-700 px-4 py-2">Batal</button>
                    <button type="submit" class="btn-compact bg-amber-500 hover:bg-amber-600 text-white shadow-sm px-4 py-2 font-medium">Simpan KKM</button>
                </div>
            </form>
        </div>
    </div>

</div>

<script>
<?php
    $riwayatJsonData = $riwayat_nilai->map(function($r) { 
        return [
            'siswa_id' => $r->siswa_id, 
            'bab' => strtolower($r->bab), 
            'tugas' => $r->tugas, 
            'quiz' => $r->quiz, 
            'proyek' => $r->proyek
        ]; 
    })->values()->all();
?>
    const riwayatData = <?php echo json_encode($riwayatJsonData, 15, 512) ?>;

    function loadExistingGrades() {
        const babInput = document.getElementById('inputBabUtama').value.trim();
        if (!babInput) {
            alert('Silakan ketik atau pilih nama Materi / Bab terlebih dahulu.');
            return;
        }
        
        const bab = babInput.toLowerCase();
        
        document.querySelectorAll('.siswa-row').forEach(row => {
            const siswaId = parseInt(row.dataset.siswa);
            const grade = riwayatData.find(g => g.siswa_id === siswaId && g.bab === bab);
            
            const tugasInput = row.querySelector('.input-tugas');
            const quizInput = row.querySelector('.input-quiz');
            const proyekInput = row.querySelector('.input-proyek');
            
            if (grade) {
                tugasInput.value = grade.tugas;
                quizInput.value = grade.quiz;
                proyekInput.value = grade.proyek;
            } else {
                tugasInput.value = 0;
                quizInput.value = 0;
                proyekInput.value = 0;
            }
            
            // Trigger AlpineJS x-model update
            tugasInput.dispatchEvent(new Event('input'));
            quizInput.dispatchEvent(new Event('input'));
            proyekInput.dispatchEvent(new Event('input'));
        });
    }

    function filterKelas() {
        const selected = document.getElementById('kelasFilter').value;
        const rows = document.querySelectorAll('.siswa-row');
        rows.forEach(row => {
            const inputs = row.querySelectorAll('input');
            if (selected === 'all' || row.dataset.kelas === selected) {
                row.style.display = '';
                inputs.forEach(input => input.disabled = false);
            } else {
                row.style.display = 'none';
                inputs.forEach(input => input.disabled = true);
            }
        });
    }

    function filterRiwayat() {
        const selectedKelas = document.getElementById('filterRiwayatKelas').value;
        const selectedBab = document.getElementById('filterRiwayatBab').value;
        const rows = document.querySelectorAll('.riwayat-row');
        
        rows.forEach(row => {
            const rowKelas = row.dataset.kelas;
            const rowBab = row.dataset.bab;
            
            const matchKelas = (selectedKelas === 'all' || rowKelas === selectedKelas);
            const matchBab = (selectedBab === 'all' || rowBab === selectedBab);
            
            if (matchKelas && matchBab) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }

    function filterRekap() {
        const selectedKelas = document.getElementById('filterRekapKelas').value;
        const rows = document.querySelectorAll('.rekap-row');
        
        rows.forEach(row => {
            const rowKelas = row.dataset.kelas;
            if (selectedKelas === 'all' || rowKelas === selectedKelas) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/vol3_7/infinityfree.com/if0_42547424/htdocs/resources/views/guru/nilai.blade.php ENDPATH**/ ?>