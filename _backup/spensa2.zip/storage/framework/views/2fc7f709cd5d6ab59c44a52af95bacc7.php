<?php $__env->startSection('title', 'Rekap Hasil & Koreksi Siswa'); ?>
<?php $__env->startSection('page_title', 'Rekap Hasil & Koreksi Siswa'); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<div class="mb-4 bg-green-100 text-green-800 p-3.5 rounded-xl text-sm border border-green-200 shadow-sm flex items-center gap-2">
    <svg class="w-5 h-5 text-green-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
    <span><?php echo e(session('success')); ?></span>
</div>
<?php endif; ?>

<?php if($errors->any()): ?>
<div class="mb-4 bg-red-100 text-red-800 p-3.5 rounded-xl text-sm border border-red-200 shadow-sm">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p>• <?php echo e($error); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>

<!-- Exam Summary Card -->
<div class="mb-6 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
    <div>
        <div class="flex items-center gap-2 mb-1">
            <span class="text-xs bg-slate-100 text-slate-600 font-extrabold px-2.5 py-0.5 rounded-md border border-slate-200 uppercase"><?php echo e($ujian->bab); ?></span>
            <span class="text-xs text-slate-400 font-semibold">KKM: <?php echo e($kkm); ?></span>
        </div>
        <h2 class="text-xl font-black text-slate-800"><?php echo e($ujian->judul); ?></h2>
    </div>

    <div class="flex items-center gap-2.5 flex-wrap">
        <?php if($hasEssay && $ujian->isSelesai()): ?>
        <a href="<?php echo e(route('guru.ujian.koreksi', $ujian->id)); ?>" class="bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold px-4 py-2.5 rounded-xl text-sm shadow-md transition-all active:scale-[0.98] flex items-center gap-1.5 border border-indigo-700">
            ✍️ Koreksi Essay Massal
        </a>
        <?php endif; ?>

        <?php if($ujian->isSelesai()): ?>
        <form action="<?php echo e(route('guru.ujian.finalisasi', $ujian->id)); ?>" method="POST" onsubmit="return confirm('Simpan & publish nilai ulangan ini ke Rekap Nilai Utama?');">
            <?php echo csrf_field(); ?>
            <button type="submit" class="bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold px-4 py-2.5 rounded-xl text-sm shadow-md transition-all active:scale-[0.98] border border-emerald-700 flex items-center gap-1.5">
                📌 Finalisasi & Push ke Rekap Nilai
            </button>
        </form>
        <?php endif; ?>

        <a href="<?php echo e(route('guru.hasil.index')); ?>" class="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold px-4 py-2.5 rounded-xl text-sm transition-all">
            ← Kembali
        </a>
    </div>
</div>

<!-- Student Results Table -->
<div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
    <div class="flex justify-between items-center pb-4 mb-4 border-b border-slate-100">
        <h3 class="font-black text-slate-800 text-base">Hasil & Lembar Pengerjaan Siswa (Total: <?php echo e($hasilUjians->count()); ?>)</h3>
    </div>

    <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse">
            <thead>
                <tr class="bg-slate-50 text-slate-600 text-xs uppercase font-extrabold border-b border-slate-200">
                    <th class="py-3 px-4 w-12 text-center">No</th>
                    <th class="py-3 px-4">Nama Siswa</th>
                    <th class="py-3 px-4">Kelas</th>
                    <th class="py-3 px-4 text-center">Skor PG</th>
                    <th class="py-3 px-4 text-center">Skor Essay</th>
                    <th class="py-3 px-4 text-center">Nilai Akhir</th>
                    <th class="py-3 px-4 text-center">Status KKM</th>
                    <th class="py-3 px-4 text-center">Deteksi Tab Switch</th>
                    <th class="py-3 px-4 text-center w-36">Aksi Inspeksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100 text-sm font-medium">
                <?php $__empty_1 = true; $__currentLoopData = $hasilUjians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-slate-50/80 transition-colors">
                    <td class="py-4 px-4 text-center text-slate-400 font-bold text-xs"><?php echo e($index + 1); ?></td>
                    <td class="py-4 px-4">
                        <span class="font-extrabold text-slate-800 block"><?php echo e($h->siswa->user->name ?? '-'); ?></span>
                        <span class="text-xs text-slate-400 font-mono">NIS: <?php echo e($h->siswa->nis ?? '-'); ?></span>
                    </td>
                    <td class="py-4 px-4 text-xs font-bold text-slate-600">
                        <?php echo e($h->siswa->kelas->nama_kelas ?? '-'); ?>

                    </td>
                    <td class="py-4 px-4 text-center font-extrabold text-slate-700">
                        <?php echo e(number_format($h->nilai_pg, 1)); ?>

                    </td>
                    <td class="py-4 px-4 text-center font-extrabold text-indigo-700">
                        <?php echo e(number_format($h->nilai_essay, 1)); ?>

                    </td>
                    <td class="py-4 px-4 text-center">
                        <span class="text-base font-black px-3 py-1 rounded-xl border <?php echo e($h->nilai_akhir >= $kkm ? 'bg-green-50 text-green-700 border-green-200' : 'bg-red-50 text-red-700 border-red-200'); ?>">
                            <?php echo e(number_format($h->nilai_akhir, 1)); ?>

                        </span>
                    </td>
                    <td class="py-4 px-4 text-center">
                        <?php if($h->nilai_akhir >= $kkm): ?>
                        <span class="px-2.5 py-0.5 bg-green-100 text-green-800 text-xs font-bold rounded-full border border-green-200">LULUS</span>
                        <?php else: ?>
                        <span class="px-2.5 py-0.5 bg-red-100 text-red-800 text-xs font-bold rounded-full border border-red-200">REMEDIAL</span>
                        <?php endif; ?>
                    </td>
                    <td class="py-4 px-4 text-center">
                        <?php if($h->tab_switch_count > 0): ?>
                        <span class="px-2.5 py-1 bg-red-100 text-red-800 text-xs font-black rounded-lg border border-red-200 flex items-center justify-center gap-1">
                            ⚠️ <?php echo e($h->tab_switch_count); ?>x Switch
                        </span>
                        <?php else: ?>
                        <span class="text-xs text-slate-400 font-semibold">Aman (0x)</span>
                        <?php endif; ?>
                    </td>
                    <td class="py-4 px-4 text-center">
                        <a href="<?php echo e(route('guru.hasil.detail-siswa', [$ujian->id, $h->siswa_id])); ?>" class="bg-blue-50 hover:bg-blue-100 text-blue-700 font-extrabold text-xs py-1.5 px-3 rounded-xl border border-blue-200 transition-all inline-block shadow-sm">
                            🔍 Periksa Jawaban
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9" class="py-8 text-center text-slate-400 text-sm font-semibold">
                        Belum ada siswa yang mengerjakan atau menyelesaikan ujian ini.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\spensa\resources\views/guru/ujian/hasil-show.blade.php ENDPATH**/ ?>