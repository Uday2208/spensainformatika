<?php $__env->startSection('title', 'Input Pembelajaran Hari Ini'); ?>
<?php $__env->startSection('page_title', '⚡ Input Pembelajaran Hari Ini'); ?>
<?php $__env->startSection('content'); ?>


<div x-data="inputPembelajaran()" x-init="init()">


<?php if(session('success')): ?>
<div x-data="{ show: true }" x-show="show" x-transition
     class="mb-5 flex items-start gap-3 bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-2xl shadow-sm">
    <div class="w-8 h-8 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
        <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"></path></svg>
    </div>
    <div class="flex-1">
        <p class="font-bold text-sm">Berhasil Disimpan!</p>
        <p class="text-xs mt-0.5 text-emerald-700"><?php echo e(session('success')); ?></p>
    </div>
    <button @click="show = false" class="text-emerald-400 hover:text-emerald-600 transition-colors">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
    </button>
</div>
<?php endif; ?>

<?php if($errors->any()): ?>
<div x-data="{ show: true }" x-show="show" x-transition
     class="mb-5 flex items-start gap-3 bg-red-50 border border-red-200 text-red-800 p-4 rounded-2xl shadow-sm">
    <div class="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
        <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
    </div>
    <div class="flex-1">
        <p class="font-bold text-sm">Terjadi Kesalahan</p>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p class="text-xs mt-0.5 text-red-700"><?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <button @click="show = false" class="text-red-400 hover:text-red-600 transition-colors">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
    </button>
</div>
<?php endif; ?>


<div class="relative overflow-hidden bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900 rounded-2xl p-5 mb-5 shadow-xl">
    <div class="absolute inset-0 opacity-10">
        <div class="absolute top-0 right-0 w-64 h-64 bg-white rounded-full -translate-y-32 translate-x-32"></div>
        <div class="absolute bottom-0 left-0 w-48 h-48 bg-amber-400 rounded-full translate-y-24 -translate-x-24"></div>
    </div>
    <div class="relative flex items-center gap-4">
        <div class="w-12 h-12 bg-amber-400 rounded-2xl flex items-center justify-center shadow-lg flex-shrink-0">
            <svg class="w-6 h-6 text-amber-900" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
        </div>
        <div class="flex-1 min-w-0">
            <h2 class="text-white font-bold text-lg leading-tight">Input Pembelajaran Hari Ini</h2>
            <p class="text-blue-200 text-xs mt-0.5">Presensi + Penilaian Harian + Jurnal Mengajar dalam 1 halaman</p>
        </div>
        <div class="hidden sm:block text-right flex-shrink-0">
            <p class="text-white font-bold text-sm"><?php echo e(\Carbon\Carbon::now()->translatedFormat('d M Y')); ?></p>
            <p class="text-blue-300 text-xs"><?php echo e(\Carbon\Carbon::now()->translatedFormat('l')); ?></p>
        </div>
    </div>
</div>


<div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-5 mb-5">
    <div class="flex items-center gap-2 mb-4">
        <div class="w-6 h-6 bg-blue-100 rounded-lg flex items-center justify-center">
            <svg class="w-3.5 h-3.5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"></path></svg>
        </div>
        <h3 class="font-bold text-slate-700 text-sm">Filter Kelas & Pertemuan</h3>
    </div>
    <form action="<?php echo e(url('app/input-pembelajaran')); ?>" method="GET" class="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div>
            <label class="block text-xs font-semibold text-slate-500 mb-1.5 uppercase tracking-wide">Kelas</label>
            <select name="kelas_id" id="kelas_id" required
                class="w-full text-sm bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-all min-h-[44px]">
                <option value="">-- Pilih Kelas --</option>
                <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($k->id); ?>" <?php echo e($kelas_id == $k->id ? 'selected' : ''); ?>><?php echo e($k->nama_kelas); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label class="block text-xs font-semibold text-slate-500 mb-1.5 uppercase tracking-wide">Tanggal</label>
            <input type="date" name="tanggal" value="<?php echo e($tanggal); ?>" required
                class="w-full text-sm bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-all min-h-[44px]">
        </div>
        <div>
            <label class="block text-xs font-semibold text-slate-500 mb-1.5 uppercase tracking-wide">Pertemuan ke-</label>
            <input type="text" name="pertemuan" value="<?php echo e($pertemuan); ?>" placeholder="Misal: 1, atau Bab 2" required
                class="w-full text-sm bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-all min-h-[44px]">
        </div>
        <div class="sm:col-span-3">
            <button type="submit"
                class="w-full sm:w-auto px-8 py-2.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold text-sm rounded-xl shadow-md shadow-blue-500/25 transition-all min-h-[44px] flex items-center justify-center gap-2">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
                Tampilkan Siswa
            </button>
        </div>
    </form>
</div>

<?php if($kelas_id && $siswas->count() > 0): ?>


<form action="<?php echo e(url('app/input-pembelajaran')); ?>" method="POST" id="form-pembelajaran">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="kelas_id" value="<?php echo e($kelas_id); ?>">
    <input type="hidden" name="tanggal" value="<?php echo e($tanggal); ?>">
    <input type="hidden" name="pertemuan" value="<?php echo e($pertemuan); ?>">

    
    <template x-for="siswa in siswas" :key="siswa.id">
        <span>
            <input type="hidden" :name="'absensi[' + siswa.id + ']'" :value="absensi[siswa.id]">
            <input type="hidden" :name="'nilai[' + siswa.id + ']'" :value="nilai[siswa.id]">
        </span>
    </template>

    
    <div class="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">

        
        <div class="md:col-span-7 space-y-4">

            
            <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-4">
                
                <div class="flex items-center justify-between mb-3">
                    <div class="flex items-center gap-2">
                        <span class="text-sm font-bold text-slate-700">Progress Input</span>
                        <span class="text-xs font-bold px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full" x-text="hadirCount + ' hadir / ' + siswas.length + ' siswa'"></span>
                    </div>
                    <div class="flex items-center gap-2">
                        <span class="w-2 h-2 rounded-full bg-emerald-400 inline-block"></span>
                        <span class="text-xs text-slate-500" x-text="aktifCount + ' aktif'"></span>
                        <span class="w-2 h-2 rounded-full bg-blue-400 inline-block ml-1"></span>
                        <span class="text-xs text-slate-500" x-text="normalCount + ' normal'"></span>
                    </div>
                </div>
                <div class="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                    <div class="h-2 bg-gradient-to-r from-blue-500 to-emerald-500 rounded-full transition-all duration-500"
                         :style="'width: ' + (hadirCount / siswas.length * 100) + '%'"></div>
                </div>

                
                <div class="flex flex-wrap gap-2 mt-4">
                    <button type="button" @click="setAllHadir()"
                        class="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-50 hover:bg-emerald-100 active:scale-95 border border-emerald-200 text-emerald-700 text-xs font-bold rounded-xl transition-all min-h-[40px]">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                        Set Semua Hadir
                    </button>
                    <button type="button" @click="setAllNormal()"
                        class="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-50 hover:bg-blue-100 active:scale-95 border border-blue-200 text-blue-700 text-xs font-bold rounded-xl transition-all min-h-[40px]">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg>
                        Set Semua Normal (80)
                    </button>
                    <button type="button" @click="resetAll()"
                        class="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-50 hover:bg-slate-100 active:scale-95 border border-slate-200 text-slate-600 text-xs font-bold rounded-xl transition-all min-h-[40px]">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                        Reset Semua
                    </button>
                </div>
            </div>

            
            <div class="flex items-center gap-2 px-1 pt-2">
                <div class="w-7 h-7 bg-indigo-100 rounded-lg flex items-center justify-center">
                    <svg class="w-4 h-4 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                </div>
                <h3 class="font-bold text-slate-700">Presensi & Penilaian Siswa</h3>
                <span class="text-xs font-semibold text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full"><?php echo e($siswas->count()); ?> siswa</span>
            </div>

            
            <div class="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm mt-3 mb-6">
                <div class="overflow-x-auto">
                    <table class="w-full text-sm text-left">
                        <thead class="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                            <tr>
                                <th class="px-4 py-3 text-center w-12">No</th>
                                <th class="px-4 py-3 min-w-[150px]">Nama Siswa</th>
                                <th class="px-4 py-3 text-center min-w-[200px]">Kehadiran</th>
                                <th class="px-4 py-3 text-center w-32">Keaktifan</th>
                                <th class="px-4 py-3 min-w-[150px]">Catatan</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            <?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $absensiAwal = $siswa->absensis->first()->status ?? 'hadir';
                                $existingNilai = $siswa->penilaianHarians->first();
                                $isHadir = in_array($absensiAwal, ['hadir', 'dispen']);
                                $nilaiAwal = $existingNilai ? $existingNilai->nilai : ($isHadir ? 80 : 60);
                                $catatanAwal = $existingNilai ? $existingNilai->catatan : '';
                            ?>
                            <tr class="hover:bg-slate-50 transition-colors"
                                :class="{
                                    'bg-red-50/50': absensi[<?php echo e($siswa->id); ?>] === 'alpha',
                                    'bg-amber-50/50': absensi[<?php echo e($siswa->id); ?>] === 'sakit',
                                    'bg-blue-50/50': absensi[<?php echo e($siswa->id); ?>] === 'izin'
                                }">
                                <td class="px-4 py-3 text-center text-slate-500 font-medium"><?php echo e($index + 1); ?></td>
                                <td class="px-4 py-3">
                                    <div class="font-bold text-slate-800"><?php echo e($siswa->user->name ?? 'Nama Siswa'); ?></div>
                                    <div class="text-xs text-slate-400">NIS: <?php echo e($siswa->nis); ?></div>
                                </td>
                                <td class="px-4 py-3">
                                    <div class="flex items-center justify-center gap-2">
                                        <label class="flex flex-col items-center gap-1 cursor-pointer group" title="Hadir">
                                            <input type="radio" x-model="absensi[<?php echo e($siswa->id); ?>]" value="hadir" @change="updateNilaiOtomatis(<?php echo e($siswa->id); ?>)" class="w-4 h-4 text-emerald-500 focus:ring-emerald-500 border-slate-300">
                                            <span class="text-[10px] font-bold text-slate-400 group-hover:text-emerald-500" :class="{'text-emerald-600': absensi[<?php echo e($siswa->id); ?>] === 'hadir'}">H</span>
                                        </label>
                                        <label class="flex flex-col items-center gap-1 cursor-pointer group" title="Sakit">
                                            <input type="radio" x-model="absensi[<?php echo e($siswa->id); ?>]" value="sakit" @change="updateNilaiOtomatis(<?php echo e($siswa->id); ?>)" class="w-4 h-4 text-amber-500 focus:ring-amber-500 border-slate-300">
                                            <span class="text-[10px] font-bold text-slate-400 group-hover:text-amber-500" :class="{'text-amber-600': absensi[<?php echo e($siswa->id); ?>] === 'sakit'}">S</span>
                                        </label>
                                        <label class="flex flex-col items-center gap-1 cursor-pointer group" title="Izin">
                                            <input type="radio" x-model="absensi[<?php echo e($siswa->id); ?>]" value="izin" @change="updateNilaiOtomatis(<?php echo e($siswa->id); ?>)" class="w-4 h-4 text-blue-500 focus:ring-blue-500 border-slate-300">
                                            <span class="text-[10px] font-bold text-slate-400 group-hover:text-blue-500" :class="{'text-blue-600': absensi[<?php echo e($siswa->id); ?>] === 'izin'}">I</span>
                                        </label>
                                        <label class="flex flex-col items-center gap-1 cursor-pointer group" title="Dispen">
                                            <input type="radio" x-model="absensi[<?php echo e($siswa->id); ?>]" value="dispen" @change="updateNilaiOtomatis(<?php echo e($siswa->id); ?>)" class="w-4 h-4 text-purple-500 focus:ring-purple-500 border-slate-300">
                                            <span class="text-[10px] font-bold text-slate-400 group-hover:text-purple-500" :class="{'text-purple-600': absensi[<?php echo e($siswa->id); ?>] === 'dispen'}">D</span>
                                        </label>
                                        <label class="flex flex-col items-center gap-1 cursor-pointer group" title="Alpha">
                                            <input type="radio" x-model="absensi[<?php echo e($siswa->id); ?>]" value="alpha" @change="updateNilaiOtomatis(<?php echo e($siswa->id); ?>)" class="w-4 h-4 text-red-500 focus:ring-red-500 border-slate-300">
                                            <span class="text-[10px] font-bold text-slate-400 group-hover:text-red-500" :class="{'text-red-600': absensi[<?php echo e($siswa->id); ?>] === 'alpha'}">A</span>
                                        </label>
                                    </div>
                                    <input type="hidden" name="absensi[<?php echo e($siswa->id); ?>]" :value="absensi[<?php echo e($siswa->id); ?>]">
                                </td>
                                <td class="px-4 py-3">
                                    <div class="flex items-center justify-center gap-2" :class="absensi[<?php echo e($siswa->id); ?>] !== 'hadir' && absensi[<?php echo e($siswa->id); ?>] !== 'dispen' ? 'opacity-50 pointer-events-none' : ''">
                                        <button type="button" @click="if(nilai[<?php echo e($siswa->id); ?>] > 0) nilai[<?php echo e($siswa->id); ?>] -= 10" class="w-6 h-6 rounded bg-slate-100 text-slate-600 hover:bg-slate-200 flex items-center justify-center font-bold text-xs border border-slate-200">-</button>
                                        <input type="number" name="nilai[<?php echo e($siswa->id); ?>]" x-model="nilai[<?php echo e($siswa->id); ?>]" class="w-10 text-center text-sm font-bold border-0 bg-transparent p-0 focus:ring-0" readonly>
                                        <button type="button" @click="if(nilai[<?php echo e($siswa->id); ?>] < 100) nilai[<?php echo e($siswa->id); ?>] += 10" class="w-6 h-6 rounded bg-slate-100 text-slate-600 hover:bg-slate-200 flex items-center justify-center font-bold text-xs border border-slate-200">+</button>
                                    </div>
                                </td>
                                <td class="px-4 py-3">
                                    <input type="text" name="catatan_siswa[<?php echo e($siswa->id); ?>]" value="<?php echo e($catatanAwal); ?>" placeholder="Catatan..." class="w-full text-xs bg-white border border-slate-200 rounded px-2 py-1.5 focus:ring-blue-500 focus:border-blue-500">
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        
        <div class="md:col-span-5 md:sticky md:top-6 mb-28">
            <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                
                <div class="bg-gradient-to-r from-violet-600 to-purple-700 p-4">
                    <div class="flex items-center gap-3">
                        <div class="w-9 h-9 bg-white/20 rounded-xl flex items-center justify-center">
                            <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
                        </div>
                        <div class="flex-1 min-w-0">
                            <h3 class="font-bold text-white text-sm">Jurnal Mengajar</h3>
                            <p class="text-violet-200 text-xs">Dokumentasi kegiatan pembelajaran hari ini</p>
                        </div>
                        <?php if($jurnal): ?>
                        <span class="text-[10px] font-bold bg-white/20 text-white px-2.5 py-1 rounded-full border border-white/30 whitespace-nowrap">
                            ✓ Sudah diisi
                        </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="p-5 space-y-5" x-data="{ jurnalKelasType: 'semua' }">
                    
                    <div class="bg-violet-50 p-4 rounded-xl border border-violet-100">
                        <label class="block text-xs font-bold text-violet-800 mb-2 uppercase tracking-wide">🔗 Gunakan Jurnal Ini Untuk:</label>
                        <div class="flex flex-col gap-2 mb-2">
                            <label class="flex items-center gap-2 cursor-pointer">
                                <input type="radio" name="jurnal_kelas_type" value="semua" class="w-4 h-4 text-violet-600 focus:ring-violet-500 border-slate-300" x-model="jurnalKelasType">
                                <span class="text-sm font-semibold text-slate-700">Semua Kelas Hari Ini</span>
                            </label>
                            <label class="flex items-center gap-2 cursor-pointer">
                                <input type="radio" name="jurnal_kelas_type" value="manual" class="w-4 h-4 text-violet-600 focus:ring-violet-500 border-slate-300" x-model="jurnalKelasType">
                                <span class="text-sm font-medium text-slate-600">Pilih Kelas Manual</span>
                            </label>
                        </div>
                        
                        <div x-show="jurnalKelasType === 'manual'" x-cloak class="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-3 pt-3 border-t border-violet-200">
                            <?php $__currentLoopData = \App\Models\Kelas::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="flex items-center gap-2 cursor-pointer bg-white px-2 py-1.5 rounded border border-slate-200 hover:border-violet-300 transition-colors">
                                <input type="checkbox" name="jurnal_kelas_ids[]" value="<?php echo e($k->id); ?>" class="text-violet-600 rounded border-slate-300 focus:ring-violet-500" <?php echo e($kelas_id == $k->id ? 'checked' : ''); ?>>
                                <span class="text-xs font-bold text-slate-600"><?php echo e($k->nama_kelas); ?></span>
                            </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    
                    <div>
                        <label class="block text-xs font-bold text-slate-600 mb-2 uppercase tracking-wide">
                            📖 Materi Pembelajaran
                        </label>
                        <input type="text" name="materi"
                            value="<?php echo e(old('materi', $jurnal->materi ?? '')); ?>"
                            placeholder="Contoh: Sistem Tata Surya, Persamaan Linear, dst..."
                            class="w-full text-sm py-3 px-4 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 focus:bg-white transition-all min-h-[44px]">
                    </div>

                    
                    <div>
                        <label class="block text-xs font-bold text-slate-600 mb-2 uppercase tracking-wide">
                            🎯 Tujuan Pembelajaran
                        </label>
                        <textarea name="tujuan_pembelajaran" rows="2"
                            placeholder="Siswa mampu memahami dan menjelaskan..."
                            class="w-full text-sm py-3 px-4 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 focus:bg-white transition-all resize-none"><?php echo e(old('tujuan_pembelajaran', $jurnal->tujuan_pembelajaran ?? '')); ?></textarea>
                    </div>

                    
                    <?php
                        $kegiatanAwal = $jurnal->kegiatan ?? old('kegiatan_pilihan_str', '');
                        $kegiatanSelected = $kegiatanAwal
                            ? collect(explode(', ', $kegiatanAwal))->filter()->values()->toArray()
                            : [];
                    ?>
                    <div x-data="{
                            selected: <?php echo e(json_encode($kegiatanSelected)); ?>,
                            toggle(item) {
                                const idx = this.selected.indexOf(item);
                                if (idx >= 0) this.selected.splice(idx, 1);
                                else this.selected.push(item);
                            },
                            isSelected(item) { return this.selected.includes(item); }
                        }">
                        <label class="block text-xs font-bold text-slate-600 mb-2 uppercase tracking-wide">
                            ⚡ Jenis Kegiatan
                        </label>
                        <div class="flex flex-wrap gap-2 mb-3">
                            <?php $__currentLoopData = ['Diskusi', 'Praktik', 'Presentasi', 'Tugas', 'Ceramah', 'Demonstrasi', 'Tanya Jawab']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button type="button" @click="toggle('<?php echo e($keg); ?>')"
                                class="px-4 py-2 text-sm font-bold rounded-xl border-2 transition-all duration-150 active:scale-95 min-h-[40px]"
                                :class="isSelected('<?php echo e($keg); ?>')
                                    ? 'bg-violet-600 border-violet-600 text-white shadow-md shadow-violet-200'
                                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:border-violet-300 hover:text-violet-600'">
                                <?php echo e($keg); ?>

                            </button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                        <input type="hidden" name="kegiatan_pilihan_combined"
                            x-effect="$el.value = selected.join(', ')">

                        <input type="text" name="kegiatan_teks"
                            value="<?php echo e(old('kegiatan_teks', '')); ?>"
                            placeholder="Kegiatan lainnya (opsional)..."
                            class="w-full text-sm py-2.5 px-4 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 focus:bg-white transition-all">
                    </div>

                    
                    <div class="grid grid-cols-1 gap-4">
                        
                        <div>
                            <label class="block text-xs font-bold text-slate-600 mb-2 uppercase tracking-wide">
                                📝 Catatan
                            </label>
                            <textarea name="catatan_jurnal" rows="2"
                                placeholder="Kendala, temuan, atau hal menarik..."
                                class="w-full text-sm py-3 px-4 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 focus:bg-white transition-all resize-none"><?php echo e(old('catatan_jurnal', $jurnal->catatan ?? '')); ?></textarea>
                        </div>
                        
                        <div>
                            <label class="block text-xs font-bold text-slate-600 mb-2 uppercase tracking-wide">
                                🔜 Tindak Lanjut
                            </label>
                            <textarea name="tindak_lanjut" rows="2"
                                placeholder="Rencana pertemuan berikutnya, remedi..."
                                class="w-full text-sm py-3 px-4 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 focus:bg-white transition-all resize-none"><?php echo e(old('tindak_lanjut', $jurnal->tindak_lanjut ?? '')); ?></textarea>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>


    
    <div class="fixed bottom-0 left-0 right-0 z-50 lg:left-[260px]">
        <div class="bg-white/95 backdrop-blur-md border-t border-slate-200 shadow-[0_-8px_24px_-4px_rgba(0,0,0,0.12)] px-4 py-3">
            <div class="max-w-7xl mx-auto flex items-center gap-3">
                
                <div class="hidden sm:flex items-center gap-4 flex-1">
                    <div class="flex items-center gap-1.5">
                        <div class="w-2.5 h-2.5 rounded-full bg-emerald-400"></div>
                        <span class="text-xs text-slate-600 font-medium" x-text="hadirCount + ' Hadir'"></span>
                    </div>
                    <div class="flex items-center gap-1.5">
                        <div class="w-2.5 h-2.5 rounded-full bg-amber-400"></div>
                        <span class="text-xs text-slate-600 font-medium" x-text="sakitCount + ' Sakit'"></span>
                    </div>
                    <div class="flex items-center gap-1.5">
                        <div class="w-2.5 h-2.5 rounded-full bg-blue-400"></div>
                        <span class="text-xs text-slate-600 font-medium" x-text="izinCount + ' Izin'"></span>
                    </div>
                    <div class="flex items-center gap-1.5">
                        <div class="w-2.5 h-2.5 rounded-full bg-red-400"></div>
                        <span class="text-xs text-slate-600 font-medium" x-text="alphaCount + ' Alpa'"></span>
                    </div>
                    <div class="h-4 w-px bg-slate-200 mx-1"></div>
                    <div class="flex items-center gap-1.5">
                        <div class="w-2.5 h-2.5 rounded-full bg-emerald-500"></div>
                        <span class="text-xs text-slate-600 font-medium" x-text="aktifCount + ' Aktif'"></span>
                    </div>
                    <div class="flex items-center gap-1.5">
                        <div class="w-2.5 h-2.5 rounded-full bg-blue-500"></div>
                        <span class="text-xs text-slate-600 font-medium" x-text="normalCount + ' Normal'"></span>
                    </div>
                </div>
                
                <button type="submit"
                    class="w-full sm:w-auto flex items-center justify-center gap-2.5 px-8 py-3.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 active:scale-95 text-white font-black text-sm rounded-2xl shadow-xl shadow-blue-500/30 transition-all duration-150 min-h-[52px]">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4"></path></svg>
                    SIMPAN SEMUA
                    <span class="bg-white/20 px-2 py-0.5 rounded-lg text-xs font-bold" x-text="siswas.length + ' siswa'"></span>
                </button>
            </div>
        </div>
    </div>

</form>

<?php elseif($kelas_id && $siswas->count() === 0): ?>
<div class="flex flex-col items-center justify-center py-20 text-center bg-white rounded-2xl border border-slate-200 shadow-sm">
    <div class="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mb-4">
        <svg class="w-10 h-10 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
    </div>
    <p class="text-slate-600 font-bold text-lg">Tidak Ada Siswa</p>
    <p class="text-slate-400 text-sm mt-1">Kelas ini belum memiliki data siswa.</p>
    <a href="<?php echo e(url('/app/data-siswa')); ?>" class="mt-4 px-6 py-2.5 bg-blue-600 text-white text-sm font-bold rounded-xl hover:bg-blue-700 transition-colors">
        Tambah Data Siswa
    </a>
</div>
<?php else: ?>
<div class="flex flex-col items-center justify-center py-24 text-center">
    <div class="w-24 h-24 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-3xl flex items-center justify-center mb-5 shadow-inner">
        <svg class="w-12 h-12 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
    </div>
    <h3 class="text-xl font-black text-slate-700 mb-2">Mulai Input Pembelajaran</h3>
    <p class="text-slate-400 text-sm max-w-xs leading-relaxed">Pilih kelas, tentukan tanggal dan pertemuan, lalu klik <strong>Tampilkan Siswa</strong> untuk memulai.</p>
    <div class="mt-6 flex flex-col sm:flex-row gap-3 text-xs text-slate-500">
        <div class="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-4 py-2.5 shadow-sm">
            <span class="text-lg">📋</span> Presensi otomatis tersimpan
        </div>
        <div class="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-4 py-2.5 shadow-sm">
            <span class="text-lg">⭐</span> Penilaian keaktifan real-time
        </div>
        <div class="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-4 py-2.5 shadow-sm">
            <span class="text-lg">📓</span> Jurnal dalam 1 klik simpan
        </div>
    </div>
</div>
<?php endif; ?>

</div>


<script>
function inputPembelajaran() {
    return {
        siswas: <?php echo json_encode($siswas->map(fn($s) => ['id' => $s->id, 'name' => $s->user->name ?? 'Siswa']), 512) ?>,

        absensi: {
            <?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $ab = $s->absensis->first()->status ?? 'hadir'; ?>
            <?php echo e($s->id); ?>: '<?php echo e($ab); ?>',
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        },

        nilai: {
            <?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $existN = $s->penilaianHarians->first();
                $isH = in_array($s->absensis->first()->status ?? 'hadir', ['hadir', 'dispen']);
                $dv = $existN ? $existN->nilai : ($isH ? 80 : 60);
            ?>
            <?php echo e($s->id); ?>: <?php echo e($dv); ?>,
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        },

        absensiLabel: {
            <?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($s->id); ?>: '',
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        },

        // ----------- Computed (via getters) -----------
        get hadirCount()  { return Object.values(this.absensi).filter(v => v === 'hadir').length; },
        get sakitCount()  { return Object.values(this.absensi).filter(v => v === 'sakit').length; },
        get izinCount()   { return Object.values(this.absensi).filter(v => v === 'izin').length; },
        get dispenCount() { return Object.values(this.absensi).filter(v => v === 'dispen').length; },
        get alphaCount()  { return Object.values(this.absensi).filter(v => v === 'alpha').length; },
        get aktifCount()  { return Object.values(this.nilai).filter(v => v === 90).length; },
        get normalCount() { return Object.values(this.nilai).filter(v => v === 80).length; },
        get pasifCount()  { return Object.values(this.nilai).filter(v => v === 70).length; },
        get tidakCount()  { return Object.values(this.nilai).filter(v => v === 60).length; },

        // ----------- Methods -----------
        init() {
            // Sync label on load
            this.siswas.forEach(s => this.updateLabel(s.id));
        },

        updateLabel(id) {
            const map = {
                hadir:  'Hadir',
                sakit:  'Sakit',
                izin:   'Izin',
                dispen: 'Dispen',
                alpha:  'Alpa',
            };
            this.absensiLabel[id] = map[this.absensi[id]] || '';
        },

        setAbsensi(id, status) {
            this.absensi[id] = status;
            this.updateLabel(id);

            // Jika tidak hadir (bukan hadir & bukan dispen), nilai otomatis 60
            const berhakNilai = (status === 'hadir' || status === 'dispen');
            if (!berhakNilai) {
                this.nilai[id] = 60;
            } else {
                // Hadir/Dispen → reset ke normal jika sebelumnya 60
                if (this.nilai[id] === 60) this.nilai[id] = 80;
            }

            // Haptic feedback
            if (window.navigator && window.navigator.vibrate) {
                window.navigator.vibrate(30);
            }
        },

        setNilai(id, val) {
            const berhakNilai = (this.absensi[id] === 'hadir' || this.absensi[id] === 'dispen');
            if (!berhakNilai) return; // Guard: hanya hadir/dispen yang bisa dapat nilai
            this.nilai[id] = val;
            if (window.navigator && window.navigator.vibrate) {
                window.navigator.vibrate(20);
            }
        },

        setAllHadir() {
            this.siswas.forEach(s => {
                this.absensi[s.id] = 'hadir';
                this.updateLabel(s.id);
                if (this.nilai[s.id] === 60) this.nilai[s.id] = 80;
            });
        },

        setAllNormal() {
            this.siswas.forEach(s => {
                if (this.absensi[s.id] === 'hadir' || this.absensi[s.id] === 'dispen') {
                    this.nilai[s.id] = 80;
                }
            });
        },

        resetAll() {
            if (!confirm('Reset semua status ke Hadir & Normal?')) return;
            this.siswas.forEach(s => {
                this.absensi[s.id] = 'hadir';
                this.nilai[s.id] = 80;
                this.updateLabel(s.id);
            });
        },
    };
}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\webpresensi\resources\views/guru/input-pembelajaran.blade.php ENDPATH**/ ?>