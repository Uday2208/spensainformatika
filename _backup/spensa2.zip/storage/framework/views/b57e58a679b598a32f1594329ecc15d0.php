<?php $__env->startSection('title', 'Lembar Periksa Jawaban Siswa'); ?>
<?php $__env->startSection('page_title', 'Lembar Periksa Jawaban Siswa'); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<div class="mb-4 bg-green-100 text-green-800 p-3.5 rounded-xl text-sm border border-green-200 shadow-sm flex items-center gap-2">
    <svg class="w-5 h-5 text-green-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
    <span><?php echo e(session('success')); ?></span>
</div>
<?php endif; ?>

<?php if($errors->any()): ?>
<div class="mb-4 bg-red-100 text-red-800 p-3.5 rounded-xl text-sm border border-red-200 shadow-sm">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p>• <?php echo e($error); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>

<!-- Top Navigation & Action -->
<div class="mb-6 flex justify-between items-center">
    <a href="<?php echo e(route('guru.hasil.show', $ujian->id)); ?>" class="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold px-4 py-2 rounded-xl text-sm transition-all inline-flex items-center gap-1.5">
        ← Kembali ke Rekap Hasil Ujian
    </a>
</div>

<!-- Grid Layout -->
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

    <!-- Left Column: Student & Exam Summary Card -->
    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 h-fit space-y-4">
        <div class="pb-3 border-b border-slate-100">
            <span class="text-xs bg-blue-50 text-blue-700 border border-blue-200 px-2.5 py-0.5 rounded-md font-bold uppercase"><?php echo e($siswa->kelas->nama_kelas ?? 'Siswa'); ?></span>
            <h2 class="text-lg font-black text-slate-800 mt-1"><?php echo e($siswa->user->name ?? '-'); ?></h2>
            <p class="text-xs text-slate-400 font-mono">NIS: <?php echo e($siswa->nis); ?></p>
        </div>

        <div class="space-y-3 text-sm">
            <div>
                <label class="text-slate-400 text-xs font-semibold block">Paket Ujian</label>
                <span class="font-bold text-slate-800 block"><?php echo e($ujian->judul); ?></span>
                <span class="text-xs text-slate-500 font-medium">Materi: <?php echo e($ujian->bab); ?></span>
            </div>

            <div class="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100">
                <div class="bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-center">
                    <label class="text-slate-400 text-[10px] font-bold block uppercase">Skor PG</label>
                    <span class="text-base font-black text-slate-800"><?php echo e(number_format($hasil->nilai_pg, 1)); ?></span>
                </div>
                <div class="bg-indigo-50/50 p-2.5 rounded-xl border border-indigo-100 text-center">
                    <label class="text-indigo-500 text-[10px] font-bold block uppercase">Skor Essay</label>
                    <span class="text-base font-black text-indigo-700"><?php echo e(number_format($hasil->nilai_essay, 1)); ?></span>
                </div>
            </div>

            <div class="p-3.5 rounded-xl border text-center <?php echo e($hasil->nilai_akhir >= $kkm ? 'bg-green-50 border-green-200 text-green-800' : 'bg-red-50 border-red-200 text-red-800'); ?>">
                <label class="text-xs font-bold block uppercase opacity-75">Nilai Akhir Ujian</label>
                <span class="text-3xl font-black block my-0.5"><?php echo e(number_format($hasil->nilai_akhir, 1)); ?></span>
                <span class="text-xs font-extrabold px-2.5 py-0.5 rounded-full inline-block <?php echo e($hasil->nilai_akhir >= $kkm ? 'bg-green-200 text-green-900' : 'bg-red-200 text-red-900'); ?>">
                    <?php echo e($hasil->nilai_akhir >= $kkm ? 'LULUS KKM (' . $kkm . ')' : 'REMEDIAL (KKM ' . $kkm . ')'); ?>

                </span>
            </div>

            <!-- Update Nilai Form -->
            <div class="pt-3 border-t border-slate-100">
                <h4 class="font-extrabold text-slate-800 text-xs mb-2">✍️ Koreksi / Override Nilai</h4>
                <form action="<?php echo e(route('guru.hasil.update-siswa', [$ujian->id, $siswa->id])); ?>" method="POST" class="space-y-3">
                    <?php echo csrf_field(); ?>
                    <?php if($ujian->soalEssay()->count() > 0): ?>
                    <div>
                        <label class="block text-[11px] font-bold text-slate-600 mb-1">Nilai Total Essay (0-100)</label>
                        <input type="number" step="0.1" name="nilai_essay" min="0" max="100" value="<?php echo e(old('nilai_essay', $hasil->nilai_essay)); ?>" class="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 text-xs font-bold text-center">
                    </div>
                    <?php endif; ?>

                    <div>
                        <label class="block text-[11px] font-bold text-slate-600 mb-1">Nilai Akhir (Opsional Override)</label>
                        <input type="number" step="0.1" name="nilai_akhir" min="0" max="100" value="<?php echo e(old('nilai_akhir', $hasil->nilai_akhir)); ?>" class="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 text-xs font-black text-center text-blue-800">
                    </div>

                    <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-extrabold py-2 px-3 rounded-xl text-xs shadow-md transition-all active:scale-[0.98]">
                        Simpan Nilai Siswa
                    </button>
                </form>
            </div>
        </div>

        <!-- Log Cheat Violations -->
        <?php if($logs->count() > 0): ?>
        <div class="bg-red-50/50 rounded-2xl border border-red-200 p-4 space-y-2">
            <h4 class="font-extrabold text-red-800 text-xs flex items-center gap-1.5">
                <span>⚠️</span> Log Deteksi Kecurangan (<?php echo e($logs->count()); ?> Aktivitas)
            </h4>
            <div class="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="text-[11px] bg-white p-2 rounded-lg border border-red-100">
                    <span class="font-mono font-bold text-red-600 block"><?php echo e(\Carbon\Carbon::parse($log->created_at)->format('H:i:s')); ?> - <?php echo e(strtoupper($log->event)); ?></span>
                    <span class="text-slate-600 font-medium"><?php echo e($log->detail); ?></span>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Right Column: Full Student Answer Sheet -->
    <div class="lg:col-span-2 space-y-6">

        <!-- Pilihan Ganda Answers -->
        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
            <h3 class="font-extrabold text-slate-800 text-base mb-4 pb-2 border-b border-slate-100 flex items-center justify-between">
                <span>1. Lembar Jawaban Pilihan Ganda (PG)</span>
                <span class="text-xs text-slate-400 font-medium">Bobot PG: <?php echo e($ujian->soalPg()->sum('bobot')); ?></span>
            </h3>

            <div class="space-y-4">
                <?php $__empty_1 = true; $__currentLoopData = $ujian->soals->where('tipe', 'pg'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $soal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $j = $jawaban[$soal->id] ?? null;
                    $jawabanSiswa = $j ? strtolower(trim($j->jawaban)) : null;
                    $jawabanBenar = strtolower(trim($soal->jawaban_benar));
                    $isCorrect = $jawabanSiswa && ($jawabanSiswa === $jawabanBenar);
                ?>
                <div class="p-4 rounded-xl border <?php echo e($isCorrect ? 'border-green-200 bg-green-50/20' : ($jawabanSiswa ? 'border-red-200 bg-red-50/20' : 'border-slate-200 bg-slate-50/30')); ?>">
                    <div class="flex justify-between items-start mb-2 gap-4">
                        <div class="flex items-center gap-2">
                            <span class="w-6 h-6 bg-slate-200 text-slate-800 rounded-full text-xs font-black flex items-center justify-center"><?php echo e($index + 1); ?></span>
                            <span class="text-xs text-slate-500 font-bold">Bobot: <?php echo e($soal->bobot); ?></span>
                        </div>
                        <div>
                            <?php if($isCorrect): ?>
                            <span class="px-2.5 py-0.5 bg-green-100 text-green-800 text-xs font-black rounded-full border border-green-200 flex items-center gap-1">
                                ✓ BENAR
                            </span>
                            <?php elseif($jawabanSiswa): ?>
                            <span class="px-2.5 py-0.5 bg-red-100 text-red-800 text-xs font-black rounded-full border border-red-200 flex items-center gap-1">
                                ✗ SALAH
                            </span>
                            <?php else: ?>
                            <span class="px-2.5 py-0.5 bg-slate-200 text-slate-600 text-xs font-bold rounded-full">
                                Tidak Dijawab
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="text-slate-800 text-sm font-semibold mb-3"><?php echo nl2br(e($soal->pertanyaan)); ?></div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                        <?php $__currentLoopData = ['a' => $soal->opsi_a, 'b' => $soal->opsi_b, 'c' => $soal->opsi_c, 'd' => $soal->opsi_d]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $opsiText): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $isChosen = ($jawabanSiswa === $key);
                            $isKunci = ($jawabanBenar === $key);
                        ?>
                        <div class="p-2 rounded-lg border transition-all flex items-center justify-between <?php echo e($isKunci ? 'bg-green-100 text-green-900 border-green-300 font-bold' : ($isChosen ? 'bg-red-100 text-red-900 border-red-300 font-bold' : 'bg-white border-slate-200 text-slate-700')); ?>">
                            <div>
                                <span class="font-extrabold uppercase mr-1"><?php echo e($key); ?>.</span> <?php echo e($opsiText); ?>

                            </div>
                            <div>
                                <?php if($isChosen && $isKunci): ?>
                                <span class="text-[10px] bg-green-600 text-white px-1.5 py-0.5 rounded font-bold">Jawaban Siswa (Benar)</span>
                                <?php elseif($isChosen): ?>
                                <span class="text-[10px] bg-red-600 text-white px-1.5 py-0.5 rounded font-bold">Jawaban Siswa</span>
                                <?php elseif($isKunci): ?>
                                <span class="text-[10px] bg-green-200 text-green-900 px-1.5 py-0.5 rounded font-bold">Kunci Benar</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-xs text-slate-400 italic">Tidak ada soal Pilihan Ganda pada ujian ini.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Essay Answers -->
        <?php if($ujian->soalEssay()->count() > 0): ?>
        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
            <h3 class="font-extrabold text-slate-800 text-base mb-4 pb-2 border-b border-slate-100 flex items-center justify-between">
                <span>2. Lembar Jawaban Essay / Uraian</span>
                <span class="text-xs text-slate-400 font-medium">Bobot Essay: <?php echo e($ujian->soalEssay()->sum('bobot')); ?></span>
            </h3>

            <div class="space-y-4">
                <?php $__currentLoopData = $ujian->soals->where('tipe', 'essay'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $soal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $j = $jawaban[$soal->id] ?? null;
                    $jawabanText = $j ? $j->jawaban : null;
                ?>
                <div class="p-4 rounded-xl border border-indigo-200 bg-indigo-50/10 space-y-3">
                    <div class="flex justify-between items-center">
                        <span class="font-extrabold text-xs text-indigo-900">Soal Essay <?php echo e($index + 1); ?> (Bobot: <?php echo e($soal->bobot); ?>)</span>
                    </div>

                    <div class="text-slate-800 text-sm font-semibold"><?php echo nl2br(e($soal->pertanyaan)); ?></div>

                    <div class="bg-white border border-slate-200 rounded-xl p-3.5">
                        <label class="text-[10px] font-bold text-slate-400 uppercase block mb-1">Jawaban Yang Diketik Siswa:</label>
                        <?php if($jawabanText): ?>
                        <div class="text-slate-800 text-sm leading-relaxed whitespace-pre-wrap font-medium"><?php echo e($jawabanText); ?></div>
                        <?php else: ?>
                        <span class="text-xs text-amber-700 italic font-semibold">Siswa tidak mengetikkan jawaban untuk soal essay ini.</span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\spensa\resources\views/guru/ujian/hasil-detail-siswa.blade.php ENDPATH**/ ?>