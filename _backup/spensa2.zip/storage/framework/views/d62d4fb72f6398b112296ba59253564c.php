<?php $__env->startSection('title', 'Kelola Artikel Web'); ?>
<?php $__env->startSection('page_title', 'Kelola Artikel & Berita'); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<div class="mb-4 bg-green-100 text-green-800 p-3 rounded text-sm border border-green-200">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if($errors->any()): ?>
<div class="mb-4 bg-red-100 text-red-800 p-3 rounded text-sm border border-red-200">
    <ul class="list-disc ml-5">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <!-- Form Upload Artikel -->
    <div class="lg:col-span-1">
        <div class="bg-white rounded border border-slate-200 shadow-sm p-4 sticky top-6">
            <h3 class="font-bold text-slate-800 mb-4 border-b border-slate-100 pb-2">Tulis Artikel Baru</h3>
            <form action="<?php echo e(url('/app/artikel')); ?>" method="POST" enctype="multipart/form-data" class="space-y-4">
                <?php echo csrf_field(); ?>
                
                <div>
                    <label class="block text-xs font-semibold text-slate-600 mb-1">Judul Artikel</label>
                    <input type="text" name="judul" required class="input-compact w-full bg-slate-50" placeholder="Ketik judul di sini...">
                </div>
                
                <div>
                    <label class="block text-xs font-semibold text-slate-600 mb-1">Isi / Konten Artikel</label>
                    <textarea name="konten" required rows="6" class="input-compact w-full bg-slate-50" placeholder="Tulis paragraf artikel Anda..."></textarea>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-600 mb-1">Gambar (Bisa pilih lebih dari satu)</label>
                    <!-- MULTIPLE UPLOAD -->
                    <input type="file" name="gambar[]" multiple accept="image/*" class="w-full text-xs text-slate-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:text-xs file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 border border-slate-200 rounded p-1 bg-slate-50">
                    <p class="text-[10px] text-slate-400 mt-1">Tekan CTRL saat memilih file untuk mengunggah beberapa gambar. Gambar akan menjadi Slideshow di halaman depan.</p>
                </div>
                
                <button type="submit" class="btn-compact w-full bg-blue-600 hover:bg-blue-700 text-white shadow-sm flex justify-center items-center">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path></svg>
                    Publikasikan Artikel
                </button>
            </form>
        </div>
    </div>

    <!-- Daftar Artikel -->
    <div class="lg:col-span-2">
        <h3 class="font-bold text-slate-800 mb-4">Artikel Terpublikasi</h3>
        
        <?php if($artikels->isEmpty()): ?>
        <div class="bg-white rounded border border-dashed border-slate-300 p-8 text-center shadow-sm">
            <svg class="w-12 h-12 text-slate-300 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"></path></svg>
            <p class="text-slate-500 font-medium">Belum ada artikel yang dipublikasikan.</p>
        </div>
        <?php else: ?>
        <div class="space-y-4">
            <?php $__currentLoopData = $artikels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white rounded border border-slate-200 shadow-sm p-4 flex flex-col sm:flex-row gap-4">
                
                <!-- Preview Gambar -->
                <div class="sm:w-48 flex-shrink-0">
                    <?php if($artikel->gambar && count($artikel->gambar) > 0): ?>
                        <div class="relative w-full h-32 rounded overflow-hidden bg-slate-100 group">
                            <img src="<?php echo e(asset('uploads/artikel/' . $artikel->gambar[0])); ?>" alt="Preview" class="w-full h-full object-cover">
                            <?php if(count($artikel->gambar) > 1): ?>
                                <div class="absolute inset-0 bg-black/40 flex items-center justify-center">
                                    <span class="text-white font-bold text-sm">+<?php echo e(count($artikel->gambar) - 1); ?> Foto</span>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <div class="w-full h-32 rounded bg-slate-100 border border-slate-200 flex items-center justify-center">
                            <span class="text-xs text-slate-400">Tanpa Gambar</span>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Konten -->
                <div class="flex-grow flex flex-col">
                    <div class="flex justify-between items-start">
                        <h4 class="font-bold text-slate-800 text-lg mb-1"><?php echo e($artikel->judul); ?></h4>
                        <!-- Tombol Hapus -->
                        <form action="<?php echo e(url('/app/artikel', $artikel->id)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus artikel ini?');" class="ml-4">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-500 hover:text-red-700 bg-red-50 hover:bg-red-100 rounded px-2 py-1 text-xs font-bold transition">Hapus</button>
                        </form>
                    </div>
                    
                    <p class="text-xs text-slate-400 mb-2">Diterbitkan: <?php echo e($artikel->created_at->format('d M Y, H:i')); ?></p>
                    
                    <p class="text-sm text-slate-600 line-clamp-3">
                        <?php echo e($artikel->konten); ?>

                    </p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\webpresensi\resources\views/guru/artikel.blade.php ENDPATH**/ ?>