<?php $__env->startSection('title', 'Rekap Kehadiran'); ?>
<?php $__env->startSection('page_title', 'Rekap Kehadiran Siswa'); ?>
<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
<div class="mb-4 bg-red-100 text-red-800 p-3 rounded text-sm border border-red-200">
    <ul class="list-disc ml-5">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<div x-data="{ searchName: '' }">
<!-- Filter & Export Controls -->
<div class="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
    <!-- Filter Per Kelas -->
    <div class="bg-white rounded border border-slate-200 shadow-sm p-4 flex flex-col justify-between">
        <h3 class="font-bold text-slate-700 text-sm mb-3 border-b border-slate-100 pb-2">Filter Berdasarkan Kelas</h3>
        <form action="<?php echo e(url('/app/rekap-absensi')); ?>" method="GET" class="flex flex-col sm:flex-row items-end gap-3 w-full">
            <div class="flex-1 w-full">
                <label class="block text-xs font-semibold text-slate-500 mb-1">Pilih Kelas</label>
                <select name="kelas_id" class="input-compact bg-slate-50 w-full cursor-pointer">
                    <option value="">-- Semua Kelas --</option>
                    <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k->id); ?>" <?php echo e($kelas_id == $k->id ? 'selected' : ''); ?>><?php echo e($k->nama_kelas); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit" class="btn-compact bg-blue-600 hover:bg-blue-700 text-white shadow-sm w-full sm:w-auto h-[30px]">Tampilkan</button>
        </form>
    </div>

    <!-- Filter Per Siswa -->
    <div class="bg-white rounded border border-slate-200 shadow-sm p-4 flex flex-col justify-between">
        <h3 class="font-bold text-slate-700 text-sm mb-3 border-b border-slate-100 pb-2">Filter Berdasarkan Nama Siswa</h3>
        <div class="flex flex-col sm:flex-row items-end gap-3 w-full">
            <div class="flex-1 w-full">
                <label class="block text-xs font-semibold text-slate-500 mb-1">Cari Nama</label>
                <input type="text" x-model="searchName" placeholder="Ketik nama siswa..." class="input-compact bg-slate-50 w-full focus:ring-indigo-500 focus:border-indigo-500">
            </div>
        </div>
    </div>
</div>

<div class="mb-4">
    <form action="<?php echo e(url('/app/rekap-absensi/export')); ?>" method="GET">
        <?php if($kelas_id): ?> <input type="hidden" name="kelas_id" value="<?php echo e($kelas_id); ?>"> <?php endif; ?>
        <?php if($nama_siswa): ?> <input type="hidden" name="nama_siswa" value="<?php echo e($nama_siswa); ?>"> <?php endif; ?>
        <button type="submit" class="btn-compact bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center shadow-sm w-full sm:w-auto">
            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
            Export CSV Hasil Filter Ini
        </button>
    </form>
</div>

<div class="bg-white rounded border border-slate-200 shadow-sm overflow-hidden">
    <?php if($siswas->isEmpty()): ?>
        <div class="p-10 text-center text-slate-500 italic border border-dashed border-slate-200 m-4 rounded">
            Tidak ada data siswa yang ditemukan.
        </div>
    <?php else: ?>
        <div class="overflow-x-auto p-4">
            <div class="flex justify-between items-center mb-4">
                <h3 class="font-bold text-slate-700 text-sm">Data Rekapitulasi</h3>
                <?php if($kelas_id): ?>
                    <a href="<?php echo e(url('/app/rekap-absensi')); ?>" class="text-xs text-blue-600 hover:underline">Tampilkan Semua Data</a>
                <?php endif; ?>
            </div>
            <table class="w-full text-left border-collapse table-compact">
                <thead>
                    <tr>
                        <th class="w-10 text-center">No</th>
                        <th>Nomer Induk</th>
                        <th>Nama Siswa</th>
                        <th class="text-center w-20">Hadir</th>
                        <th class="text-center w-20">Sakit</th>
                        <th class="text-center w-20">Izin</th>
                        <th class="text-center w-20">Dispen</th>
                        <th class="text-center w-20">Alpha</th>
                        <th class="text-center w-24 bg-emerald-50">% Hadir</th>
                        <th class="text-center w-24">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $hadir = $siswa->absensis->where('status', 'hadir')->count();
                            $sakit = $siswa->absensis->where('status', 'sakit')->count();
                            $izin = $siswa->absensis->where('status', 'izin')->count();
                            $dispen = $siswa->absensis->where('status', 'dispen')->count();
                            $alpha = $siswa->absensis->where('status', 'alpha')->count();
                            $totalHari = $hadir + $sakit + $izin + $dispen + $alpha;
                            $persen = $totalHari > 0 ? round(($hadir / $totalHari) * 100) : 0;
                        ?>
                        <tr class="hover:bg-slate-50 transition-colors" x-show="searchName === '' || '<?php echo e(strtolower(addslashes($siswa->user->name ?? ''))); ?>'.includes(searchName.toLowerCase())">
                            <td class="text-center text-slate-500"><?php echo e($index + 1); ?></td>
                            <td class="font-mono text-slate-600"><?php echo e($siswa->nis); ?></td>
                            <td class="font-medium text-slate-800"><?php echo e($siswa->user->name ?? '-'); ?></td>
                            <td class="text-center font-bold text-green-600 bg-green-50/50"><?php echo e($hadir); ?></td>
                            <td class="text-center font-bold text-blue-600 bg-blue-50/50"><?php echo e($sakit); ?></td>
                            <td class="text-center font-bold text-yellow-600 bg-yellow-50/50"><?php echo e($izin); ?></td>
                            <td class="text-center font-bold text-purple-600 bg-purple-50/50"><?php echo e($dispen); ?></td>
                            <td class="text-center font-bold text-red-600 bg-red-50/50"><?php echo e($alpha); ?></td>
                            <td class="text-center font-black text-sm
                                <?php echo e($persen >= 80 ? 'text-emerald-700 bg-emerald-50' : ($persen >= 60 ? 'text-amber-700 bg-amber-50' : 'text-red-700 bg-red-50')); ?>">
                                <?php echo e($totalHari > 0 ? $persen . '%' : '-'); ?>

                            </td>
                            <td class="text-center">
                                <a href="<?php echo e(url('/app/rekap-absensi/siswa/' . $siswa->id)); ?>" class="btn-compact bg-blue-100 text-blue-700 hover:bg-blue-600 hover:text-white transition-colors text-xs inline-flex items-center justify-center">
                                    <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
                                    Detail
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\webpresensi\resources\views/guru/rekap-absensi.blade.php ENDPATH**/ ?>