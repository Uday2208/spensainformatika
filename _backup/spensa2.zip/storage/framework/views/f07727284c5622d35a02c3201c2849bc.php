<?php $__env->startSection('title', 'Rapor Akademik'); ?>
<?php $__env->startSection('page_title', 'Rapor & Rekapitulasi'); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<div class="mb-4 bg-green-100 text-green-800 p-3 rounded text-sm border border-green-200">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if($errors->any()): ?>
<div class="mb-4 bg-red-100 text-red-800 p-3 rounded text-sm border border-red-200">
    <ul class="list-disc ml-5">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
    <!-- Identitas Siswa -->
    <div class="lg:col-span-2 bg-white rounded border border-slate-200 p-4 shadow-sm flex items-center">
        <div class="w-16 h-16 rounded border border-slate-200 bg-slate-50 flex items-center justify-center text-2xl font-bold text-slate-400 mr-4">
            <?php echo e(substr(auth()->user()->name, 0, 1)); ?>

        </div>
        <div>
            <h2 class="text-xl font-bold text-slate-800"><?php echo e(auth()->user()->name); ?></h2>
            <div class="text-sm text-slate-600 mt-1 flex gap-4">
                <span>Nomer Induk: <strong class="font-mono"><?php echo e($siswa->nis ?? 'Tidak ditemukan'); ?></strong></span>
                <span>Kelas: <strong><?php echo e($siswa->kelas->nama_kelas ?? 'Belum ada kelas'); ?></strong></span>
            </div>
        </div>
    </div>

    <!-- Ringkasan Singkat -->
    <div class="bg-white rounded border border-slate-200 p-4 shadow-sm flex flex-col justify-center">
        <?php
            $rataRata = $nilais->avg('nilai_akhir') ?? 0;
            $rataKeaktifan = $penilaianHarians->count() > 0 ? $penilaianHarians->avg('nilai') : 80;
            $totalAbsen = $absensis->count();
            $hadir = $absensis->where('status', 'hadir')->count();
            $sakit = $absensis->where('status', 'sakit')->count();
            $izin = $absensis->where('status', 'izin')->count();
            $dispen = $absensis->where('status', 'dispen')->count();
            $alpha = $absensis->where('status', 'alpha')->count();
            $persentaseHadir = $totalAbsen > 0 ? ($hadir / $totalAbsen) * 100 : 0;
        ?>
        <div class="flex justify-between items-center mb-2.5 pb-2 border-b border-slate-100">
            <div>
                <span class="block text-sm text-slate-600">Rata-rata Nilai Akhir:</span>
                <span class="text-[10px] font-bold <?php echo e($rataRata >= $kkm ? 'text-green-600' : 'text-red-500'); ?>">
                    Status: <?php echo e($rataRata >= $kkm ? 'TUNTAS' : 'BELUM TUNTAS'); ?> (KKM: <?php echo e($kkm); ?>)
                </span>
            </div>
            <span class="font-bold text-2xl <?php echo e($rataRata >= $kkm ? 'text-green-600' : 'text-red-600'); ?>"><?php echo e(number_format($rataRata, 1)); ?></span>
        </div>

        <div class="flex justify-between items-center mb-2.5 pb-2 border-b border-slate-100">
            <div>
                <span class="block text-sm text-slate-600">Rata-rata Keaktifan Harian:</span>
                <span class="text-[10px] font-bold text-blue-600">
                    Sikap & Partisipasi Kelas
                </span>
            </div>
            <span class="font-bold text-2xl text-blue-600"><?php echo e(number_format($rataKeaktifan, 1)); ?></span>
        </div>

        <div class="flex justify-between items-center">
            <div>
                <span class="block text-sm text-slate-600">Kehadiran (<?php echo e(number_format($persentaseHadir, 0)); ?>%):</span>
                <span class="text-[10px] font-medium text-slate-500">
                    H: <?php echo e($hadir); ?> | S: <?php echo e($sakit); ?> | I: <?php echo e($izin); ?> | D: <?php echo e($dispen); ?> | A: <?php echo e($alpha); ?>

                </span>
            </div>
            <span class="font-bold text-2xl <?php echo e($persentaseHadir >= 80 ? 'text-blue-600' : 'text-red-600'); ?>"><?php echo e($totalAbsen); ?><span class="text-xs text-slate-400 font-normal">hari</span></span>
        </div>
    </div>
</div>

<div class="bg-white rounded border border-slate-200 shadow-sm overflow-hidden" x-data="{ tab: 'nilai' }">
    <!-- Tabs -->
    <div class="flex border-b border-slate-200 bg-slate-50 overflow-x-auto">
        <button @click="tab = 'nilai'" :class="tab === 'nilai' ? 'bg-white border-b-2 border-blue-600 text-blue-700 font-bold' : 'text-slate-600 hover:bg-slate-100'" class="px-5 py-3 text-sm transition-colors whitespace-nowrap">
            Daftar Nilai
        </button>
        <button @click="tab = 'absensi'" :class="tab === 'absensi' ? 'bg-white border-b-2 border-blue-600 text-blue-700 font-bold' : 'text-slate-600 hover:bg-slate-100'" class="px-5 py-3 text-sm transition-colors border-l border-slate-200 whitespace-nowrap">
            Kehadiran
        </button>
        <button @click="tab = 'materi'" :class="tab === 'materi' ? 'bg-white border-b-2 border-blue-600 text-blue-700 font-bold' : 'text-slate-600 hover:bg-slate-100'" class="px-5 py-3 text-sm transition-colors border-l border-slate-200 whitespace-nowrap">
            Materi Belajar
        </button>
        <button @click="tab = 'profil'" :class="tab === 'profil' ? 'bg-white border-b-2 border-blue-600 text-blue-700 font-bold' : 'text-slate-600 hover:bg-slate-100'" class="px-5 py-3 text-sm transition-colors border-l border-slate-200 whitespace-nowrap">
            Akun
        </button>
        <button @click="tab = 'testimoni'" :class="tab === 'testimoni' ? 'bg-white border-b-2 border-blue-600 text-blue-700 font-bold' : 'text-slate-600 hover:bg-slate-100'" class="px-5 py-3 text-sm transition-colors border-l border-slate-200 whitespace-nowrap">
            Testimoni
        </button>
    </div>

    <!-- Tab Nilai -->
    <div x-show="tab === 'nilai'" class="p-0">
        <?php if($nilais->isEmpty()): ?>
        <div class="p-8 text-center text-slate-500 italic">Belum ada nilai yang diinput oleh Guru.</div>
        <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse table-compact">
                <thead>
                    <tr>
                        <th class="w-12 text-center">No</th>
                        <th>Materi / Bab</th>
                        <th class="w-24 text-center">Tugas</th>
                        <th class="w-24 text-center">Quiz</th>
                        <th class="w-24 text-center">Proyek</th>
                        <th class="w-32 text-center bg-slate-100">Nilai Akhir</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $nilais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-slate-50">
                        <td class="text-center text-slate-500"><?php echo e($index + 1); ?></td>
                        <td class="font-bold text-slate-700"><?php echo e($nilai->bab); ?></td>
                        <td class="text-center text-slate-600"><?php echo e($nilai->tugas == 0 ? '-' : $nilai->tugas); ?></td>
                        <td class="text-center text-slate-600"><?php echo e($nilai->quiz == 0 ? '-' : $nilai->quiz); ?></td>
                        <td class="text-center text-slate-600"><?php echo e($nilai->proyek == 0 ? '-' : $nilai->proyek); ?></td>
                        <td class="text-center font-bold <?php echo e($nilai->nilai_akhir >= $kkm ? 'text-green-700 bg-green-50' : 'text-red-700 bg-red-50'); ?> flex items-center justify-center space-x-2 p-2">
                            <span><?php echo e($nilai->nilai_akhir); ?></span>
                            <?php if($nilai->nilai_akhir >= $kkm): ?>
                                <span class="px-1.5 py-0.5 bg-green-200 text-green-800 text-[9px] rounded uppercase">Tuntas</span>
                            <?php else: ?>
                                <span class="px-1.5 py-0.5 bg-red-200 text-red-800 text-[9px] rounded uppercase">Remedial</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>

    <!-- Tab Absensi (Rekap Mingguan & Harian) -->
    <div x-show="tab === 'absensi'" x-cloak class="p-4 sm:p-6 bg-slate-50 space-y-6">
        
        <!-- Header Legend -->
        <div class="bg-white rounded-xl p-4 border border-slate-200 shadow-sm flex flex-wrap justify-between items-center gap-3">
            <div>
                <h3 class="font-extrabold text-slate-800 text-sm flex items-center gap-2">
                    <span>📅 Rekap Kehadiran Siswa Per Minggu</span>
                </h3>
                <p class="text-xs text-slate-500 mt-0.5">Rekapitulasi kehadiran dihitung per minggu (Minggu 1 - 5) untuk setiap bulan.</p>
            </div>
            
            <!-- Legend Badges -->
            <div class="flex items-center gap-1.5 flex-wrap text-xs font-bold">
                <span class="px-2.5 py-1 bg-green-100 text-green-800 rounded-lg border border-green-200">H: Hadir</span>
                <span class="px-2.5 py-1 bg-blue-100 text-blue-800 rounded-lg border border-blue-200">S: Sakit</span>
                <span class="px-2.5 py-1 bg-yellow-100 text-yellow-800 rounded-lg border border-yellow-200">I: Izin</span>
                <span class="px-2.5 py-1 bg-red-100 text-red-800 rounded-lg border border-red-200">A: Alpha</span>
                <span class="px-2.5 py-1 bg-purple-100 text-purple-800 rounded-lg border border-purple-200">D: Dispen</span>
            </div>
        </div>

        <?php if(empty($rekapAbsensiMingguan)): ?>
        <div class="bg-white rounded-xl border border-slate-200 p-8 text-center text-slate-500 italic shadow-sm">
            Belum ada data absensi yang tercatat.
        </div>
        <?php else: ?>
        
        <!-- Matrix Rekap Mingguan Per Bulan -->
        <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div class="p-4 bg-slate-100/80 border-b border-slate-200 flex justify-between items-center">
                <h4 class="font-black text-slate-800 text-sm">📊 Tabel Rekapitulasi Mingguan (Per Bulan)</h4>
                <span class="text-xs font-bold text-slate-500">Kolom Minggu per Bulan</span>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="bg-slate-50 text-slate-700 text-xs font-extrabold border-b border-slate-200 uppercase">
                            <th class="py-3 px-4 w-44">Bulan & Tahun</th>
                            <th class="py-3 px-3 text-center w-40 bg-blue-50/50 border-x border-slate-200">Minggu 1 (Tgl 1-7)</th>
                            <th class="py-3 px-3 text-center w-40 bg-blue-50/50 border-x border-slate-200">Minggu 2 (Tgl 8-14)</th>
                            <th class="py-3 px-3 text-center w-40 bg-blue-50/50 border-x border-slate-200">Minggu 3 (Tgl 15-21)</th>
                            <th class="py-3 px-3 text-center w-40 bg-blue-50/50 border-x border-slate-200">Minggu 4 (Tgl 22-28)</th>
                            <th class="py-3 px-3 text-center w-40 bg-blue-50/50 border-x border-slate-200">Minggu 5 (Tgl 29+)</th>
                            <th class="py-3 px-4 text-center w-44 bg-emerald-50">Total Bulan Ini</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 text-xs font-medium">
                        <?php $__currentLoopData = $rekapAbsensiMingguan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulan => $weeks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $totH = 0; $totS = 0; $totI = 0; $totA = 0; $totD = 0;
                            foreach($weeks as $w) {
                                $totH += $w['H']; $totS += $w['S']; $totI += $w['I']; $totA += $w['A']; $totD += $w['D'];
                            }
                        ?>
                        <tr class="hover:bg-slate-50/80 transition-colors">
                            <td class="py-4 px-4 font-black text-slate-800 text-sm">
                                📅 <?php echo e($bulan); ?>

                            </td>

                            <?php for($m = 1; $m <= 5; $m++): ?>
                            <?php
                                $wKey = 'Minggu ' . $m;
                                $wData = $weeks[$wKey] ?? null;
                            ?>
                            <td class="py-3 px-2 text-center border-x border-slate-100 <?php echo e($wData ? 'bg-white' : 'bg-slate-50/40'); ?>">
                                <?php if($wData): ?>
                                    <div class="flex items-center justify-center gap-1 flex-wrap">
                                        <span class="px-1.5 py-0.5 bg-green-100 text-green-800 font-black rounded text-[10px]" title="Hadir">H:<?php echo e($wData['H']); ?></span>
                                        <span class="px-1.5 py-0.5 bg-blue-100 text-blue-800 font-black rounded text-[10px]" title="Sakit">S:<?php echo e($wData['S']); ?></span>
                                        <span class="px-1.5 py-0.5 bg-yellow-100 text-yellow-800 font-black rounded text-[10px]" title="Izin">I:<?php echo e($wData['I']); ?></span>
                                        <span class="px-1.5 py-0.5 bg-red-100 text-red-800 font-black rounded text-[10px]" title="Alpha">A:<?php echo e($wData['A']); ?></span>
                                        <span class="px-1.5 py-0.5 bg-purple-100 text-purple-800 font-black rounded text-[10px]" title="Dispen">D:<?php echo e($wData['D']); ?></span>
                                    </div>
                                <?php else: ?>
                                    <span class="text-slate-300 font-mono text-[10px]">-</span>
                                <?php endif; ?>
                            </td>
                            <?php endfor; ?>

                            <td class="py-3 px-4 text-center font-bold bg-emerald-50/50">
                                <div class="flex items-center justify-center gap-1 flex-wrap">
                                    <span class="px-1.5 py-0.5 bg-green-200 text-green-900 font-black rounded text-[10px]">H: <?php echo e($totH); ?></span>
                                    <span class="px-1.5 py-0.5 bg-blue-200 text-blue-900 font-black rounded text-[10px]">S: <?php echo e($totS); ?></span>
                                    <span class="px-1.5 py-0.5 bg-yellow-200 text-yellow-900 font-black rounded text-[10px]">I: <?php echo e($totI); ?></span>
                                    <span class="px-1.5 py-0.5 bg-red-200 text-red-900 font-black rounded text-[10px]">A: <?php echo e($totA); ?></span>
                                    <span class="px-1.5 py-0.5 bg-purple-200 text-purple-900 font-black rounded text-[10px]">D: <?php echo e($totD); ?></span>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Tabel Rincian Per Tanggal -->
        <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div class="p-4 bg-slate-100/80 border-b border-slate-200">
                <h4 class="font-black text-slate-800 text-sm">📋 Rincian Presensi Harian (Per Tanggal)</h4>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse text-xs">
                    <thead>
                        <tr class="bg-slate-50 text-slate-600 font-extrabold uppercase border-b border-slate-200">
                            <th class="py-3 px-4 w-12 text-center">No</th>
                            <th class="py-3 px-4">Tanggal Presensi</th>
                            <th class="py-3 px-4 text-center w-40">Status Kehadiran</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 font-medium">
                        <?php $__currentLoopData = $absensis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $absen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-slate-50">
                            <td class="py-3 px-4 text-center text-slate-400 font-bold"><?php echo e($index + 1); ?></td>
                            <td class="py-3 px-4 font-bold text-slate-700"><?php echo e(\Carbon\Carbon::parse($absen->tanggal)->translatedFormat('l, d F Y')); ?></td>
                            <td class="py-3 px-4 text-center">
                                <?php if($absen->status == 'hadir'): ?>
                                    <span class="px-3 py-1 bg-green-100 text-green-800 rounded-full font-black text-[11px] border border-green-200 inline-block">Hadir (H)</span>
                                <?php elseif($absen->status == 'sakit'): ?>
                                    <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full font-black text-[11px] border border-blue-200 inline-block">Sakit (S)</span>
                                <?php elseif($absen->status == 'izin'): ?>
                                    <span class="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full font-black text-[11px] border border-yellow-200 inline-block">Izin (I)</span>
                                <?php elseif($absen->status == 'dispen'): ?>
                                    <span class="px-3 py-1 bg-purple-100 text-purple-800 rounded-full font-black text-[11px] border border-purple-200 inline-block">Dispen (D)</span>
                                <?php else: ?>
                                    <span class="px-3 py-1 bg-red-100 text-red-800 rounded-full font-black text-[11px] border border-red-200 inline-block">Alpha (A)</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php endif; ?>
    </div>

    <!-- Tab Materi Belajar -->
    <div x-show="tab === 'materi'" x-cloak class="p-4 sm:p-6 bg-slate-50">
        <?php if(isset($materis) && $materis->isEmpty()): ?>
        <div class="bg-white rounded border border-dashed border-slate-300 p-8 text-center shadow-sm">
            <svg class="w-12 h-12 text-slate-300 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
            <p class="text-slate-500 font-medium">Belum ada materi belajar yang dibagikan guru.</p>
        </div>
        <?php else: ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
            <?php $__currentLoopData = $materis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white rounded border border-slate-200 shadow-sm overflow-hidden flex flex-col group hover:shadow-md transition-shadow">
                <?php if($materi->foto): ?>
                    <div class="h-32 sm:h-40 w-full overflow-hidden bg-slate-100">
                        <img src="<?php echo e(asset('uploads/materi/' . $materi->foto)); ?>" alt="<?php echo e($materi->judul); ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
                    </div>
                <?php else: ?>
                    <div class="h-32 sm:h-40 w-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center">
                        <svg class="w-12 h-12 text-white/50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"></path></svg>
                    </div>
                <?php endif; ?>
                
                <div class="p-4 flex flex-col flex-grow">
                    <h4 class="font-bold text-slate-800 line-clamp-2 leading-tight mb-2"><?php echo e($materi->judul); ?></h4>
                    
                    <p class="text-xs text-slate-500 mb-4 flex-grow line-clamp-3">
                        <?php echo e($materi->deskripsi ?: 'Tidak ada deskripsi.'); ?>

                    </p>
                    
                    <div class="mt-auto flex flex-col gap-2 pt-3 border-t border-slate-100">
                        <span class="text-[10px] font-medium text-slate-400 flex items-center mb-1">
                            <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                            <?php echo e($materi->created_at->diffForHumans()); ?>

                        </span>
                        
                        <div class="flex items-center justify-between">
                            <?php if($materi->file_materi): ?>
                            <a href="<?php echo e(asset('uploads/materi/' . $materi->file_materi)); ?>" target="_blank" class="text-xs font-bold text-green-700 bg-green-100 hover:bg-green-200 px-3 py-1.5 rounded-full flex items-center transition-colors shadow-sm w-max">
                                <svg class="w-3 h-3 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                                Unduh File
                            </a>
                            <?php else: ?>
                            <span></span>
                            <?php endif; ?>

                            <?php if($materi->link): ?>
                            <a href="<?php echo e($materi->link); ?>" target="_blank" class="text-xs font-bold text-blue-600 bg-blue-50 hover:bg-blue-100 px-3 py-1.5 rounded-full flex items-center transition-colors">
                                Buka Link
                                <svg class="w-3 h-3 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path></svg>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- Tab Profil -->
    <div x-show="tab === 'profil'" x-cloak class="p-6">
        <h3 class="font-bold text-slate-700 mb-4 border-b border-slate-100 pb-2 text-sm">Ganti Username & Password</h3>
        
        <form action="<?php echo e(url('/app/profil')); ?>" method="POST" class="max-w-sm space-y-4">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            
            <div>
                <label class="block text-xs font-semibold text-slate-600 mb-1">Username (Untuk Login)</label>
                <input type="text" name="username" value="<?php echo e(auth()->user()->username); ?>" required class="input-compact w-full bg-slate-50">
                <p class="text-[10px] text-slate-400 mt-1">Defaultnya adalah Nomer Induk Anda.</p>
            </div>
            
            <div>
                <label class="block text-xs font-semibold text-slate-600 mb-1">Password Baru (Opsional)</label>
                <input type="password" name="password" placeholder="Kosongkan jika tidak ingin mengubah" class="input-compact w-full bg-slate-50">
                <p class="text-[10px] text-slate-400 mt-1">Isi minimal 4 karakter jika ingin mengganti sandi.</p>
            </div>
            
            <div class="pt-2">
                <button type="submit" class="btn-compact bg-blue-600 hover:bg-blue-700 text-white shadow-sm">Simpan Perubahan</button>
            </div>
        </form>
    </div>

    <!-- Tab Testimoni -->
    <div x-show="tab === 'testimoni'" x-cloak class="p-6">
        <h3 class="font-bold text-slate-700 mb-4 border-b border-slate-100 pb-2 text-sm">Kirim Testimoni</h3>
        
        <form action="<?php echo e(url('/app/komentar')); ?>" method="POST" class="max-w-xl space-y-4">
            <?php echo csrf_field(); ?>
            
            <div>
                <label class="block text-xs font-semibold text-slate-600 mb-1">Isi Komentar</label>
                <textarea name="isi_komentar" required maxlength="300" rows="4" class="input-compact w-full bg-slate-50" placeholder="Tuliskan pengalaman atau masukan Anda di sini..."></textarea>
                <p class="text-[10px] text-slate-400 mt-1">Maksimal 300 karakter. Komentar hanya bisa dikirim 1x setiap 7 hari.</p>
            </div>
            
            <div class="flex items-center mt-2">
                <input type="checkbox" name="is_anonim" id="is_anonim" value="1" class="w-4 h-4 text-blue-600 bg-slate-100 border-slate-300 rounded focus:ring-blue-500">
                <label for="is_anonim" class="ml-2 text-sm font-medium text-slate-700">Tampilkan sebagai Anonim (sembunyikan nama saya)</label>
            </div>
            
            <div class="pt-2">
                <button type="submit" class="btn-compact bg-blue-600 hover:bg-blue-700 text-white shadow-sm">Kirim Komentar</button>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\spensa\resources\views/siswa/dashboard.blade.php ENDPATH**/ ?>