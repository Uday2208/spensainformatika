<?php $__env->startSection('title', 'Mengerjakan Ujian'); ?>
<?php $__env->startSection('page_title', ''); ?>
<?php $__env->startSection('content'); ?>

<!-- Hide Sidebar & Header for distraction-free exam environment -->
<style>
    /* Desktop sidebar and layout overrides */
    aside, 
    .bg-gradient-to-b.from-blue-900, 
    div[class*="w-[260px]"],
    [class*="translate-x-0"] {
        display: none !important;
    }
    header, 
    .h-\[60px\],
    [class*="h-[60px]"] {
        display: none !important;
    }
    main {
        padding: 0 !important;
    }
    .max-w-7xl {
        max-width: 100% !important;
        padding-bottom: 0 !important;
        padding: 0 !important;
    }
    body {
        overflow: auto !important;
        background-color: #f8fafc !important;
    }
</style>

<div class="min-h-screen bg-slate-50 flex flex-col pb-20 relative select-none" 
     x-data="ujianState(<?php echo e($sisaDetik); ?>, <?php echo e($ujian->id); ?>)" 
     x-init="initUjian()">
     
    <!-- Sticky Top Header -->
    <div class="sticky top-0 bg-white border-b border-slate-200 px-4 py-3 shadow-sm z-40 flex items-center justify-between">
        <div class="min-w-0">
            <h2 class="text-sm sm:text-base font-extrabold text-slate-800 truncate"><?php echo e($ujian->judul); ?></h2>
            <div class="flex items-center gap-2 mt-0.5">
                <span class="text-[10px] bg-slate-100 border border-slate-200 text-slate-600 px-2 py-0.5 rounded font-bold uppercase"><?php echo e($ujian->bab); ?></span>
                <!-- Auto save status indicator -->
                <span class="text-xs flex items-center gap-1.5" :class="saveStatus === 'saved' ? 'text-green-600' : (saveStatus === 'saving' ? 'text-blue-500' : 'text-red-500 font-bold')">
                    <span class="w-1.5 h-1.5 rounded-full" :class="saveStatus === 'saved' ? 'bg-green-500' : (saveStatus === 'saving' ? 'bg-blue-500' : 'bg-red-500')"></span>
                    <span x-text="saveStatusText"></span>
                </span>
            </div>
        </div>

        <!-- Right Side: Timer & Submit Button -->
        <div class="flex items-center gap-3">
            <!-- Timer -->
            <div class="bg-blue-50 border border-blue-200 text-blue-800 font-mono font-extrabold px-3 py-1.5 rounded-xl flex items-center gap-1.5 text-sm sm:text-base">
                <svg class="w-4 h-4 text-blue-600 animate-spin" style="animation-duration: 3s;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                <span x-text="timerText">00:00:00</span>
            </div>

            <!-- Submit -->
            <button @click="confirmSubmit()" class="bg-red-600 hover:bg-red-700 text-white font-extrabold px-4 py-2 rounded-xl text-sm sm:text-base active:scale-[0.98] transition-all shadow-md">
                Kumpulkan
            </button>
        </div>
    </div>

    <!-- Main Content Area: List of questions -->
    <div class="max-w-3xl mx-auto w-full px-4 py-6 space-y-6">
        <?php $__currentLoopData = $ujian->soals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $soal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-4 sm:p-5" id="soal-container-<?php echo e($soal->id); ?>">
            <div class="flex items-center gap-2 mb-3">
                <span class="w-7 h-7 bg-blue-100 text-blue-800 border border-blue-200 rounded-full text-xs font-black flex items-center justify-center"><?php echo e($index + 1); ?></span>
                <span class="text-xs bg-slate-100 border border-slate-200 text-slate-500 font-bold px-2 py-0.5 rounded uppercase"><?php echo e($soal->tipe); ?></span>
                <span class="text-xs text-slate-400 font-medium">Bobot: <?php echo e($soal->bobot); ?></span>
            </div>

            <!-- Pertanyaan -->
            <div class="text-slate-800 font-semibold text-sm sm:text-base mb-4 select-text leading-relaxed">
                <?php echo nl2br(e($soal->pertanyaan)); ?>

            </div>

            <!-- Jawaban Input -->
            <?php if($soal->tipe === 'pg'): ?>
            <!-- Pilihan Ganda -->
            <div class="space-y-2.5">
                <?php
                    $valTersimpan = $jawabanTersimpan[$soal->id] ?? null;
                ?>
                <?php $__currentLoopData = ['a' => $soal->opsi_a, 'b' => $soal->opsi_b, 'c' => $soal->opsi_c, 'd' => $soal->opsi_d]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $opsiText): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="flex items-center gap-3 p-3 rounded-xl border cursor-pointer select-none transition-all active:bg-blue-50" 
                       :class="jawabanState['<?php echo e($soal->id); ?>'] === '<?php echo e($key); ?>' ? 'border-blue-500 bg-blue-50/20 font-bold text-blue-900' : 'border-slate-200 hover:bg-slate-50 text-slate-700'">
                    <input type="radio" 
                           name="jawaban_<?php echo e($soal->id); ?>" 
                           value="<?php echo e($key); ?>" 
                           @change="saveJawabanPg(<?php echo e($soal->id); ?>, '<?php echo e($key); ?>')"
                           :checked="jawabanState['<?php echo e($soal->id); ?>'] === '<?php echo e($key); ?>'"
                           class="w-4 h-4 text-blue-600 border-slate-300 focus:ring-blue-500 cursor-pointer">
                    <span class="text-xs sm:text-sm font-bold uppercase text-slate-400"><?php echo e($key); ?>.</span>
                    <span class="text-xs sm:text-sm leading-tight"><?php echo e($opsiText); ?></span>
                </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php else: ?>
            <!-- Essay / Uraian -->
            <div>
                <textarea rows="4" 
                          placeholder="Ketik jawaban uraian Anda di sini..." 
                          @input="queueSaveEssay(<?php echo e($soal->id); ?>, $event.target.value)"
                          class="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs sm:text-sm font-medium text-slate-800 placeholder:text-slate-400 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                          x-text="jawabanState['<?php echo e($soal->id); ?>'] || ''"><?php echo e($jawabanTersimpan[$soal->id] ?? ''); ?></textarea>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Modal: Cheat Warning Overlay -->
    <div x-show="showWarningModal" style="display: none;" class="fixed inset-0 z-50 overflow-y-auto bg-black bg-opacity-70 flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl p-6 shadow-2xl w-full max-w-sm text-center">
            <div class="w-14 h-14 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-4 border border-red-200">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
            </div>
            <h3 class="font-extrabold text-red-600 text-lg mb-2">Peringatan Kecurangan!</h3>
            <p class="text-sm text-slate-600 mb-4 font-semibold leading-relaxed">
                Anda terdeteksi keluar dari aplikasi/tab ujian! Tindakan ini telah dicatat oleh sistem pengawas ujian.
            </p>
            <div class="bg-red-50 text-red-700 text-xs font-bold py-2 px-3 rounded-lg mb-5 border border-red-100">
                Jumlah Pelanggaran: <span x-text="switchCount">0</span>
            </div>
            <button @click="dismissWarning()" class="w-full bg-red-600 hover:bg-red-700 text-white font-extrabold py-2.5 px-4 rounded-xl shadow-md transition-all active:scale-[0.98] text-sm">
                Lanjutkan Ujian
            </button>
        </div>
    </div>

    <!-- Modal: Submit Confirmation -->
    <div x-show="showConfirmModal" style="display: none;" class="fixed inset-0 z-50 overflow-y-auto bg-black bg-opacity-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl p-6 shadow-2xl w-full max-w-sm text-center">
            <div class="w-14 h-14 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 border border-blue-200">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            </div>
            <h3 class="font-extrabold text-slate-800 text-lg mb-2">Kumpulkan Ujian?</h3>
            <p class="text-sm text-slate-600 mb-5 leading-relaxed font-semibold">
                Apakah Anda yakin ingin menyelesaikan dan mengumpulkan hasil ujian ini? Jawaban tidak dapat diubah lagi setelah dikirim.
            </p>
            <div class="flex gap-2">
                <button @click="showConfirmModal = false" class="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-2.5 px-4 rounded-xl transition-all active:scale-[0.98] text-sm">
                    Batal
                </button>
                <button @click="submitUjian('manual')" class="flex-1 bg-red-600 hover:bg-red-700 text-white font-extrabold py-2.5 px-4 rounded-xl shadow-md transition-all active:scale-[0.98] text-sm">
                    Kumpulkan
                </button>
            </div>
        </div>
    </div>

</div>

<!-- AJAX and Anti-cheat Script -->
<script>
    function ujianState(sisaDetik, ujianId) {
        return {
            sisaWaktu: sisaDetik,
            ujianId: ujianId,
            timerText: '00:00:00',
            saveStatus: 'saved',
            saveStatusText: 'Semua jawaban tersimpan',
            showWarningModal: false,
            showConfirmModal: false,
            switchCount: 0,
            timerInterval: null,
            essayTimeouts: {},
            jawabanState: {},

            initUjian() {
                // Initialize local state of answers from Blade values
                <?php $__currentLoopData = $ujian->soals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(isset($jawabanTersimpan[$soal->id])): ?>
                        this.jawabanState['<?php echo e($soal->id); ?>'] = '<?php echo e($jawabanTersimpan[$soal->id]); ?>';
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                // Anti cheat listener
                this.setupAntiCheat();

                // Start timer
                this.startTimer();
            },

            setupAntiCheat() {
                let hasLeft = false;

                // Tab visibility change
                document.addEventListener('visibilitychange', () => {
                    if (document.visibilityState === 'hidden') {
                        if (!hasLeft) {
                            hasLeft = true;
                            this.logCheat('tab_switch', 'Siswa berganti tab browser atau meminimalkan aplikasi');
                        }
                    }
                });

                // Window blur
                window.addEventListener('blur', () => {
                    if (!hasLeft) {
                        hasLeft = true;
                        this.logCheat('blur', 'Siswa berpindah fokus ke aplikasi lain');
                    }
                });

                // Window focus
                window.addEventListener('focus', () => {
                    hasLeft = false;
                });
            },

            logCheat(event, detail) {
                fetch('<?php echo e(route("siswa.ujian.log")); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: JSON.stringify({
                        ujian_id: this.ujianId,
                        event: event,
                        detail: detail
                    })
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success && data.switch_count !== undefined) {
                        this.switchCount = data.switch_count;
                        this.showWarningModal = true;
                    }
                })
                .catch(err => console.error('Gagal mencatat log aktivitas:', err));
            },

            dismissWarning() {
                this.showWarningModal = false;
            },

            // Format timer countdown
            startTimer() {
                const updateDisplay = () => {
                    if (this.sisaWaktu <= 0) {
                        clearInterval(this.timerInterval);
                        this.submitUjian('waktu_habis');
                        return;
                    }
                    this.sisaWaktu--;
                    
                    const jam = Math.floor(this.sisaWaktu / 3600);
                    const menit = Math.floor((this.sisaWaktu % 3600) / 60);
                    const detik = this.sisaWaktu % 60;
                    
                    this.timerText = [
                        jam.toString().padStart(2, '0'),
                        menit.toString().padStart(2, '0'),
                        detik.toString().padStart(2, '0')
                    ].join(':');
                };

                updateDisplay();
                this.timerInterval = setInterval(updateDisplay, 1000);
            },

            // Save multiple choice selection
            saveJawabanPg(soalId, pilihan) {
                this.jawabanState[soalId] = pilihan;
                this.saveStatus = 'saving';
                this.saveStatusText = 'Menyimpan jawaban...';

                this.postAnswer(soalId, pilihan);
            },

            // Debounce essay inputs
            queueSaveEssay(soalId, text) {
                this.jawabanState[soalId] = text;
                this.saveStatus = 'saving';
                this.saveStatusText = 'Mengetik...';

                if (this.essayTimeouts[soalId]) {
                    clearTimeout(this.essayTimeouts[soalId]);
                }

                this.essayTimeouts[soalId] = setTimeout(() => {
                    this.postAnswer(soalId, text);
                }, 1200); // Wait for 1.2s before auto-save to reduce InfinityFree hits
            },

            // Post answer to server
            postAnswer(soalId, jawaban) {
                fetch(`<?php echo e(url('/app/ujian-siswa')); ?>/${this.ujianId}/simpan-jawaban`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: JSON.stringify({
                        soal_id: soalId,
                        jawaban: jawaban
                    })
                })
                .then(res => {
                    if (!res.ok) throw new Error('Network response not ok');
                    return res.json();
                })
                .then(data => {
                    if (data.success) {
                        this.saveStatus = 'saved';
                        this.saveStatusText = 'Semua jawaban tersimpan';
                    } else {
                        this.saveStatus = 'error';
                        this.saveStatusText = 'Gagal menyimpan. Cek koneksi internet Anda!';
                    }
                })
                .catch(err => {
                    this.saveStatus = 'error';
                    this.saveStatusText = 'Gagal menyimpan. Cek koneksi!';
                    console.error('Error saving answer:', err);
                });
            },

            confirmSubmit() {
                this.showConfirmModal = true;
            },

            submitUjian(reasonType) {
                let reason = 'Siswa submit manual';
                if (reasonType === 'waktu_habis') {
                    reason = 'Ujian selesai otomatis karena waktu habis';
                }

                // Show submitting loading overlay
                this.saveStatus = 'saving';
                this.saveStatusText = 'Sedang mengirim lembar ujian...';

                fetch(`<?php echo e(url('/app/ujian-siswa')); ?>/${this.ujianId}/submit`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: JSON.stringify({
                        reason: reason
                    })
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        window.location.href = data.redirect;
                    } else {
                        alert('Gagal mengumpulkan ujian: ' + data.message);
                        this.saveStatus = 'error';
                        this.saveStatusText = 'Gagal mengirim.';
                    }
                })
                .catch(err => {
                    console.error(err);
                    // Fallback to standard form post
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = `<?php echo e(url('/app/ujian-siswa')); ?>/${this.ujianId}/submit`;
                    
                    const csrfInput = document.createElement('input');
                    csrfInput.type = 'hidden';
                    csrfInput.name = '_token';
                    csrfInput.value = '<?php echo e(csrf_token()); ?>';
                    form.appendChild(csrfInput);

                    const reasonInput = document.createElement('input');
                    reasonInput.type = 'hidden';
                    reasonInput.name = 'reason';
                    reasonInput.value = reason;
                    form.appendChild(reasonInput);

                    document.body.appendChild(form);
                    form.submit();
                });
            }
        };
    }

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\spensa\resources\views/siswa/ujian/kerjakan.blade.php ENDPATH**/ ?>