<?php $__env->startSection('title', 'Monitoring Ujian'); ?>
<?php $__env->startSection('page_title', 'Monitoring Ujian'); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<div class="mb-4 bg-green-100 text-green-800 p-3 rounded text-sm border border-green-200 shadow-sm">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<div class="mb-4 flex items-center justify-between">
    <div class="flex items-center gap-2">
        <h2 class="text-lg font-bold text-slate-800"><?php echo e($ujian->judul); ?></h2>
        <?php if($ujian->isAktif()): ?>
        <span class="px-2 py-0.5 bg-green-100 text-green-800 text-xs font-bold rounded-full border border-green-200 animate-pulse">AKTIF</span>
        <?php else: ?>
        <span class="px-2 py-0.5 bg-amber-100 text-amber-800 text-xs font-bold rounded-full border border-amber-200">SELESAI</span>
        <?php endif; ?>
    </div>
    <div class="flex items-center gap-2">
        <?php if($ujian->isAktif()): ?>
        <span class="text-sm font-semibold text-slate-500">Token: <span class="font-mono font-bold text-slate-800 bg-slate-100 px-2 py-1 rounded border border-slate-200"><?php echo e($ujian->token); ?></span></span>
        <?php endif; ?>
        <a href="<?php echo e(route('guru.ujian.index')); ?>" class="btn-compact bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold text-xs py-1.5 px-3 rounded">Kembali</a>
    </div>
</div>

<div x-data="{ activeTab: 'peserta' }">
    <!-- Tabs -->
    <div class="flex border-b border-slate-200 mb-4">
        <button @click="activeTab = 'peserta'" :class="activeTab === 'peserta' ? 'border-b-2 border-blue-600 text-blue-700 font-bold' : 'text-slate-600 hover:text-slate-900'" class="px-4 py-2.5 text-sm transition-all focus:outline-none">
            Status Peserta (<?php echo e($hasilUjians->count()); ?>)
        </button>
        <button @click="activeTab = 'logs'" :class="activeTab === 'logs' ? 'border-b-2 border-blue-600 text-blue-700 font-bold' : 'text-slate-600 hover:text-slate-900'" class="px-4 py-2.5 text-sm transition-all focus:outline-none">
            Log Aktivitas / Kecurangan (<?php echo e($logs->count()); ?>)
        </button>
    </div>

    <!-- Tab: Status Peserta -->
    <div x-show="activeTab === 'peserta'" class="bg-white rounded border border-slate-200 shadow-sm p-4">
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse table-compact">
                <thead>
                    <tr class="bg-slate-50 text-slate-700 text-xs uppercase font-bold border-b border-slate-200">
                        <th class="py-3 px-4 w-12 text-center">No</th>
                        <th class="py-3 px-4">Nama Siswa</th>
                        <th class="py-3 px-4 text-center">Kelas</th>
                        <th class="py-3 px-4 text-center">Mulai</th>
                        <th class="py-3 px-4 text-center">Selesai</th>
                        <th class="py-3 px-4 text-center">Jawaban Disimpan</th>
                        <th class="py-3 px-4 text-center">Peringatan Tab</th>
                        <th class="py-3 px-4 text-center">Status</th>
                        <th class="py-3 px-4 text-center">Skor PG</th>
                        <th class="py-3 px-4 text-center">Nilai Akhir</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 text-sm">
                    <?php $__empty_1 = true; $__currentLoopData = $hasilUjians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-slate-50 transition-colors">
                        <td class="py-3 px-4 text-center text-slate-500"><?php echo e($index + 1); ?></td>
                        <td class="py-3 px-4 font-semibold text-slate-800"><?php echo e($hasil->siswa->user->name ?? '-'); ?></td>
                        <td class="py-3 px-4 text-center text-slate-600"><?php echo e($hasil->siswa->kelas->nama_kelas ?? '-'); ?></td>
                        <td class="py-3 px-4 text-center text-slate-600 font-mono text-xs"><?php echo e($hasil->started_at ? \Carbon\Carbon::parse($hasil->started_at)->format('H:i:s') : '-'); ?></td>
                        <td class="py-3 px-4 text-center text-slate-600 font-mono text-xs"><?php echo e($hasil->finished_at ? \Carbon\Carbon::parse($hasil->finished_at)->format('H:i:s') : '-'); ?></td>
                        <td class="py-3 px-4 text-center">
                            <span class="font-bold text-slate-700"><?php echo e($hasil->jawaban_count); ?></span>
                            <span class="text-slate-400">/ <?php echo e($totalSoal); ?></span>
                        </td>
                        <td class="py-3 px-4 text-center">
                            <span class="inline-block px-2 py-0.5 rounded-full text-xs font-bold <?php echo e($hasil->tab_switch_count > 3 ? 'bg-red-100 text-red-700 border border-red-200' : ($hasil->tab_switch_count > 0 ? 'bg-amber-100 text-amber-700 border border-amber-200' : 'bg-slate-100 text-slate-500')); ?>">
                                <?php echo e($hasil->tab_switch_count); ?>x
                            </span>
                        </td>
                        <td class="py-3 px-4 text-center">
                            <?php if($hasil->status === 'mengerjakan'): ?>
                            <span class="inline-block px-2.5 py-0.5 bg-blue-100 text-blue-700 text-xs font-bold rounded-full border border-blue-200 animate-pulse">Mengerjakan</span>
                            <?php elseif($hasil->status === 'selesai'): ?>
                            <span class="inline-block px-2.5 py-0.5 bg-indigo-100 text-indigo-700 text-xs font-bold rounded-full border border-indigo-200">Selesai (Koreksi)</span>
                            <?php else: ?>
                            <span class="inline-block px-2.5 py-0.5 bg-green-100 text-green-700 text-xs font-bold rounded-full border border-green-200">Dinilai</span>
                            <?php endif; ?>
                        </td>
                        <td class="py-3 px-4 text-center font-bold text-slate-700"><?php echo e($hasil->nilai_pg); ?></td>
                        <td class="py-3 px-4 text-center font-bold text-lg text-blue-700 bg-blue-50/20"><?php echo e($hasil->nilai_akhir); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="10" class="text-center py-8 text-slate-500 italic">Belum ada siswa memulai ujian ini.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Tab: Log Aktivitas -->
    <div x-show="activeTab === 'logs'" x-cloak class="bg-white rounded border border-slate-200 shadow-sm p-4">
        <div class="max-h-[500px] overflow-y-auto">
            <table class="w-full text-left border-collapse table-compact">
                <thead>
                    <tr class="bg-slate-50 text-slate-700 text-xs uppercase font-bold border-b border-slate-200">
                        <th class="py-3 px-4">Waktu</th>
                        <th class="py-3 px-4">Siswa</th>
                        <th class="py-3 px-4 text-center">Event</th>
                        <th class="py-3 px-4">Detail</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 text-sm">
                    <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-slate-50 transition-colors <?php echo e(in_array($log->event, ['tab_switch', 'minimize', 'blur', 'keluar']) ? 'bg-red-50/30' : ''); ?>">
                        <td class="py-3 px-4 text-slate-500 font-mono text-xs w-40"><?php echo e(\Carbon\Carbon::parse($log->created_at)->format('d M Y H:i:s')); ?></td>
                        <td class="py-3 px-4 font-semibold text-slate-800"><?php echo e($log->siswa->user->name ?? '-'); ?> (<?php echo e($log->siswa->kelas->nama_kelas ?? '-'); ?>)</td>
                        <td class="py-3 px-4 text-center">
                            <?php if(in_array($log->event, ['tab_switch', 'minimize', 'blur', 'keluar'])): ?>
                            <span class="inline-block px-2 py-0.5 bg-red-100 text-red-700 text-xs font-bold rounded border border-red-200">CURIGA</span>
                            <?php elseif($log->event === 'mulai'): ?>
                            <span class="inline-block px-2 py-0.5 bg-green-100 text-green-700 text-xs font-bold rounded border border-green-200">MULAI</span>
                            <?php else: ?>
                            <span class="inline-block px-2 py-0.5 bg-slate-100 text-slate-700 text-xs font-bold rounded border border-slate-200">INFO</span>
                            <?php endif; ?>
                        </td>
                        <td class="py-3 px-4 text-slate-700 font-semibold"><?php echo e($log->detail); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="text-center py-8 text-slate-500 italic">Belum ada log aktivitas masuk.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\spensa\resources\views/guru/ujian/monitoring.blade.php ENDPATH**/ ?>