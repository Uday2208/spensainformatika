@extends('layouts.public')
@section('title', 'Beranda - Guru Informatika')
@section('content')

<!-- Hero Section -->
<div class="relative bg-white overflow-hidden">
    <div class="absolute inset-y-0 w-full h-full bg-slate-50 opacity-50"></div>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div class="pt-16 pb-24 md:pt-24 md:pb-32 lg:flex lg:items-center lg:gap-12">
            
            <!-- Hero Text -->
            <div class="lg:w-1/2 text-center lg:text-left">
                <div class="inline-flex items-center px-3 py-1 rounded-full bg-blue-50 text-blue-600 text-xs font-bold uppercase tracking-wider mb-6 border border-blue-100">
                    <span class="w-2 h-2 rounded-full bg-blue-500 mr-2 animate-pulse"></span>
                    Sistem Akademik Terpadu
                </div>
                <h1 class="text-4xl tracking-tight font-extrabold text-slate-900 sm:text-5xl md:text-6xl lg:leading-tight">
                    <span class="block text-slate-800">Transformasi Digital</span>
                    <span class="block text-brand">Ruang Kelas Anda</span>
                </h1>
                <p class="mt-5 text-base text-slate-500 sm:mt-6 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-8 md:text-xl lg:mx-0">
                    Platform manajemen pembelajaran all-in-one yang menyederhanakan presensi, penilaian, hingga distribusi materi. Didesain khusus untuk meningkatkan efisiensi guru dan produktivitas siswa.
                </p>
                
                <div class="mt-8 sm:mt-10 flex flex-col sm:flex-row justify-center lg:justify-start gap-4">
                    <a href="{{ url('/login') }}" class="inline-flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-lg text-white bg-brand hover:bg-blue-600 shadow-lg shadow-blue-500/30 transition-all hover:-translate-y-0.5">
                        Mulai Sekarang
                        <svg class="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                    </a>
                    <a href="#features" class="inline-flex items-center justify-center px-8 py-3 border border-slate-200 text-base font-medium rounded-lg text-slate-700 bg-white hover:bg-slate-50 hover:border-slate-300 transition-all">
                        Pelajari Fitur
                    </a>
                </div>
            </div>

            <!-- Hero Image/Illustration -->
            <div class="lg:w-1/2 mt-16 lg:mt-0 relative hidden md:block">
                <!-- Background decorative elements -->
                <div class="absolute inset-0 flex items-center justify-center">
                    <div class="w-72 h-72 rounded-full bg-blue-400 opacity-20 blur-3xl animate-pulse"></div>
                    <div class="w-64 h-64 rounded-full bg-indigo-400 opacity-20 blur-3xl absolute translate-x-20 translate-y-20"></div>
                </div>
                
                <!-- Main Image -->
                <div class="relative z-10 rounded-2xl overflow-hidden shadow-2xl border border-slate-100/50 transform transition hover:scale-[1.02] duration-500">
                    <img src="{{ asset('images/hero_illustration.png') }}" alt="Digital Education Dashboard" class="w-full object-cover">
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Stats Section -->
<div class="bg-brand">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-12">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <div class="bg-white/10 rounded-xl p-6 backdrop-blur-sm border border-white/20">
                <div class="text-4xl font-extrabold text-white mb-2">{{ $stats['siswa'] ?? 0 }}<span class="text-blue-200">+</span></div>
                <div class="text-blue-100 font-medium">Siswa Terdaftar</div>
            </div>
            <div class="bg-white/10 rounded-xl p-6 backdrop-blur-sm border border-white/20">
                <div class="text-4xl font-extrabold text-white mb-2">{{ $stats['kelas'] ?? 0 }}</div>
                <div class="text-blue-100 font-medium">Kelas Aktif</div>
            </div>
            <div class="bg-white/10 rounded-xl p-6 backdrop-blur-sm border border-white/20">
                <div class="text-4xl font-extrabold text-white mb-2">{{ $stats['materi'] ?? 0 }}<span class="text-blue-200">+</span></div>
                <div class="text-blue-100 font-medium">Materi Pembelajaran</div>
            </div>
        </div>
    </div>
</div>

<!-- Features Section -->
<section id="features" class="py-20 bg-slate-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center max-w-3xl mx-auto mb-16">
            <h2 class="text-base font-bold text-brand tracking-wide uppercase">Fitur Unggulan</h2>
            <p class="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-slate-900 sm:text-4xl">
                Semua yang Anda butuhkan untuk mengelola kelas modern.
            </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <!-- Feature 1 -->
            <div class="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-lg transition-shadow duration-300 group">
                <div class="w-12 h-12 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-brand group-hover:text-white transition-all">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
                </div>
                <h3 class="text-lg font-bold text-slate-800 mb-2">Manajemen Siswa</h3>
                <p class="text-sm text-slate-500 leading-relaxed">
                    Kelola data siswa dan pembagian kelas dengan mudah. Dilengkapi fitur import/export otomatis via CSV.
                </p>
            </div>

            <!-- Feature 2 -->
            <div class="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-lg transition-shadow duration-300 group">
                <div class="w-12 h-12 rounded-lg bg-green-50 text-green-600 flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-green-500 group-hover:text-white transition-all">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"></path></svg>
                </div>
                <h3 class="text-lg font-bold text-slate-800 mb-2">Presensi Akurat</h3>
                <p class="text-sm text-slate-500 leading-relaxed">
                    Sistem absen harian dengan status detail. Otomatis merekap kehadiran per siswa dalam format laporan yang rapi.
                </p>
            </div>

            <!-- Feature 3 -->
            <div class="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-lg transition-shadow duration-300 group">
                <div class="w-12 h-12 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-purple-500 group-hover:text-white transition-all">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>
                </div>
                <h3 class="text-lg font-bold text-slate-800 mb-2">Penilaian Cerdas</h3>
                <p class="text-sm text-slate-500 leading-relaxed">
                    Fleksibel mengatur bobot tugas. Dilengkapi KKM dinamis dan label kelulusan otomatis untuk memudahkan evaluasi.
                </p>
            </div>

            <!-- Feature 4 -->
            <div class="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-lg transition-shadow duration-300 group">
                <div class="w-12 h-12 rounded-lg bg-orange-50 text-orange-600 flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-orange-500 group-hover:text-white transition-all">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
                </div>
                <h3 class="text-lg font-bold text-slate-800 mb-2">Materi Pembelajaran</h3>
                <p class="text-sm text-slate-500 leading-relaxed">
                    Berbagi bahan ajar, modul, dan link tugas langsung ke dashboard siswa. Mengubah kelas Anda menjadi mini LMS.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- Berita & Artikel Web -->
@if(isset($artikels) && $artikels->count() > 0)
<section id="artikel" class="py-20 bg-white border-t border-slate-100">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center max-w-3xl mx-auto mb-16">
            <h2 class="text-base font-bold text-brand tracking-wide uppercase">Artikel & Informasi</h2>
            <p class="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-slate-900 sm:text-4xl">
                Kabar Terbaru dari Kelas
            </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            @foreach($artikels as $artikel)
            <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden hover:shadow-lg transition-shadow duration-300 flex flex-col">
                
                <!-- Image / Carousel -->
                @if($artikel->gambar && is_array($artikel->gambar) && count($artikel->gambar) > 0)
                    @if(count($artikel->gambar) == 1)
                        <div class="w-full h-48 overflow-hidden bg-slate-100">
                            <img src="{{ asset('uploads/artikel/' . $artikel->gambar[0]) }}" alt="{{ $artikel->judul }}" class="w-full h-full object-cover">
                        </div>
                    @else
                        <!-- Carousel -->
                        <div x-data="{ activeSlide: 0, slides: {{ count($artikel->gambar) }} }" class="relative w-full h-48 bg-slate-100 overflow-hidden group">
                            <!-- Slides -->
                            <div class="w-full h-full relative">
                                @foreach($artikel->gambar as $index => $img)
                                <div x-show="activeSlide === {{ $index }}" x-transition.opacity.duration.500ms class="absolute inset-0">
                                    <img src="{{ asset('uploads/artikel/' . $img) }}" class="w-full h-full object-cover">
                                </div>
                                @endforeach
                            </div>
                            
                            <!-- Prev/Next Buttons (Show on hover) -->
                            <button @click="activeSlide = activeSlide === 0 ? slides - 1 : activeSlide - 1" class="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/30 hover:bg-black/50 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path></svg>
                            </button>
                            <button @click="activeSlide = activeSlide === slides - 1 ? 0 : activeSlide + 1" class="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/30 hover:bg-black/50 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
                            </button>
                            
                            <!-- Indicators -->
                            <div class="absolute bottom-3 left-0 right-0 flex justify-center gap-1.5 z-10">
                                @foreach($artikel->gambar as $index => $img)
                                <button @click="activeSlide = {{ $index }}" :class="activeSlide === {{ $index }} ? 'bg-white w-4' : 'bg-white/50 w-2 hover:bg-white/80'" class="h-2 rounded-full transition-all duration-300"></button>
                                @endforeach
                            </div>
                        </div>
                    @endif
                @else
                    <div class="w-full h-10 bg-slate-100"></div> <!-- Spacer if no image -->
                @endif
                
                <!-- Content -->
                <div class="p-6 flex flex-col flex-grow">
                    <div class="text-xs font-semibold text-brand mb-2 flex items-center">
                        <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                        {{ $artikel->created_at->translatedFormat('d M Y') }}
                    </div>
                    <h3 class="text-xl font-bold text-slate-900 mb-3 line-clamp-2 leading-tight">
                        {{ $artikel->judul }}
                    </h3>
                    <p class="text-slate-600 text-sm line-clamp-4 leading-relaxed mb-4">
                        {{ $artikel->konten }}
                    </p>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>
@endif

<!-- Testimonials -->
@if(isset($komentars) && $komentars->count() > 0)
<style>
    @keyframes scrollMarquee {
        0% { transform: translateX(0); }
        100% { transform: translateX(-50%); }
    }
    .marquee-track {
        display: flex;
        width: max-content;
        animation: scrollMarquee {{ max($komentars->count() * 4, 15) }}s linear infinite;
    }
    .marquee-container:hover .marquee-track {
        animation-play-state: paused;
    }
    .fade-edges {
        mask-image: linear-gradient(to right, transparent, black 5%, black 95%, transparent);
        -webkit-mask-image: linear-gradient(to right, transparent, black 5%, black 95%, transparent);
    }
</style>

<section class="py-20 bg-white border-t border-slate-100 overflow-hidden">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
        <div class="text-center">
            <h2 class="text-base font-bold text-brand tracking-wide uppercase">Testimoni Pengguna</h2>
            <p class="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-slate-900 sm:text-4xl">
                Suara dari Kelas Kita
            </p>
        </div>
    </div>
    
    <div class="marquee-container w-full overflow-hidden fade-edges py-4">
        <div class="marquee-track gap-6 px-4">
            {{-- Loop dua kali untuk efek infinite marquee --}}
            @for ($i = 0; $i < 2; $i++)
                @foreach($komentars as $komentar)
                <div class="w-80 sm:w-96 flex-shrink-0 bg-slate-50 p-6 rounded-2xl border border-slate-100 flex flex-col justify-between transform transition hover:-translate-y-1 hover:shadow-md">
                    <div>
                        <svg class="w-8 h-8 text-blue-200 mb-4" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z"/>
                        </svg>
                        <p class="text-slate-700 italic mb-6 leading-relaxed line-clamp-4">"{{ $komentar->isi_komentar }}"</p>
                    </div>
                    <div class="flex items-center gap-4 mt-auto">
                        <div class="w-12 h-12 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold text-xl border-2 border-white shadow-sm">
                            {{ $komentar->is_anonim ? 'A' : substr($komentar->siswa->user->name ?? 'A', 0, 1) }}
                        </div>
                        <div>
                            <p class="font-bold text-sm text-slate-900">{{ $komentar->is_anonim ? 'Siswa Anonim' : ($komentar->siswa->user->name ?? 'Anonim') }}</p>
                            <p class="text-xs text-slate-500">{{ \Carbon\Carbon::parse($komentar->created_at)->diffForHumans() }}</p>
                        </div>
                    </div>
                </div>
                @endforeach
            @endfor
        </div>
    </div>
</section>
@endif

<!-- Final CTA Section -->
<section class="bg-slate-900 relative overflow-hidden">
    <!-- Decorative background -->
    <div class="absolute inset-0">
        <div class="absolute inset-0 bg-blue-600 mix-blend-multiply opacity-20"></div>
        <div class="absolute -top-24 -right-24 w-96 h-96 bg-brand rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse"></div>
        <div class="absolute -bottom-24 -left-24 w-96 h-96 bg-purple-600 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse" style="animation-delay: 2s;"></div>
    </div>
    
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-24 relative z-10 text-center">
        <h2 class="text-3xl font-extrabold text-white sm:text-4xl">
            <span class="block">Siap untuk memulai?</span>
            <span class="block text-blue-400 mt-2">Akses dashboard Anda sekarang.</span>
        </h2>
        <p class="mt-4 text-lg leading-6 text-slate-300">
            Guru dapat mulai mengelola kelas, dan siswa dapat melihat perkembangan akademiknya dalam hitungan detik.
        </p>
        <div class="mt-8 flex justify-center">
            <a href="{{ url('/login') }}" class="inline-flex items-center justify-center px-8 py-3 border border-transparent text-base font-bold rounded-lg text-slate-900 bg-white hover:bg-slate-100 shadow-lg shadow-white/10 transition-all hover:-translate-y-0.5">
                Login ke Sistem
                <svg class="ml-2 w-5 h-5 text-brand" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"></path></svg>
            </a>
        </div>
    </div>
</section>

@endsection
