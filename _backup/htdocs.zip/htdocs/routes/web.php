<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PublicController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\GuruController;
use App\Http\Controllers\SiswaController;

// Public Routes
Route::get('/', [PublicController::class, 'index']);
Route::get('/about', [PublicController::class, 'about']);
Route::get('/portfolio', [PublicController::class, 'portfolio']);
Route::get('/blog', [PublicController::class, 'blog']);

// Auth Routes
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// App Routes (Must be logged in)
Route::prefix('app')->middleware('auth')->group(function () {
    
    // Universal App Routes
    Route::post('/avatar', [AuthController::class, 'updateAvatar']);

    // Guru Routes
    Route::middleware('role:guru')->group(function () {
        Route::get('/dashboard-guru', [GuruController::class, 'dashboard']);
        Route::get('/artikel', [GuruController::class, 'artikel']);
        Route::post('/artikel', [GuruController::class, 'storeArtikel']);
        Route::delete('/artikel/{id}', [GuruController::class, 'destroyArtikel']);
        Route::get('/materi', [GuruController::class, 'materi']);
        Route::post('/materi', [GuruController::class, 'storeMateri']);
        Route::delete('/materi/{id}', [GuruController::class, 'destroyMateri']);
        Route::get('/data-kelas', [GuruController::class, 'dataKelas']);
        Route::post('/data-kelas', [GuruController::class, 'storeKelas']);
        Route::delete('/data-kelas/{id}', [GuruController::class, 'destroyKelas']);
        Route::get('/data-siswa', [GuruController::class, 'dataSiswa']);
        Route::post('/data-siswa', [GuruController::class, 'storeSiswa']);
        Route::put('/data-siswa/{id}', [GuruController::class, 'updateSiswa']);
        Route::delete('/data-siswa/{id}', [GuruController::class, 'destroySiswa']);
        Route::post('/data-siswa/{id}/reset-password', [GuruController::class, 'resetPasswordSiswa']);
        Route::post('/import-siswa', [GuruController::class, 'importSiswa']);
        Route::get('/export-siswa', [GuruController::class, 'exportSiswa']);
        Route::get('/absensi', [GuruController::class, 'absensi']);
        Route::post('/absensi', [GuruController::class, 'storeAbsensi']);
        Route::delete('/absensi/delete-by-date', [GuruController::class, 'destroyAbsensiByDate']);
        Route::get('/penilaian-harian', [GuruController::class, 'penilaianHarian']);
        Route::post('/penilaian-harian', [GuruController::class, 'storePenilaianHarian']);
        Route::get('/nilai', [GuruController::class, 'nilai']);
        Route::post('/nilai', [GuruController::class, 'storeNilai']);
        Route::put('/nilai/{id}', [GuruController::class, 'updateNilai']);
        Route::delete('/nilai/{id}', [GuruController::class, 'destroyNilai']);
        Route::get('/kelola-komentar', [GuruController::class, 'kelolaKomentar']);
        Route::delete('/komentar/{id}', [GuruController::class, 'destroyKomentar']);
        Route::post('/setting-komentar', [GuruController::class, 'updateSettingKomentar']);
        Route::post('/setting-kkm', [GuruController::class, 'updateSettingKkm']);
        Route::get('/rekap-absensi', [GuruController::class, 'rekapAbsensi']);
        Route::get('/rekap-absensi/export', [GuruController::class, 'exportRekapAbsensi']);
        Route::get('/rekap-absensi/siswa/{id}', [GuruController::class, 'rekapAbsensiSiswa']);
        Route::get('/rekap-absensi/siswa/{id}/export', [GuruController::class, 'exportRekapAbsensiSiswa']);
        Route::get('/rekap-jurnal', [GuruController::class, 'rekapJurnal']);
        Route::get('/pengaturan', [GuruController::class, 'pengaturan']);
        Route::post('/pengaturan', [GuruController::class, 'storePengaturan']);

    });

    // Siswa Routes
    Route::middleware('role:siswa')->group(function () {
        Route::get('/dashboard-siswa', [SiswaController::class, 'dashboard']);
        Route::put('/profil', [SiswaController::class, 'updateProfil']);
        Route::post('/komentar', [SiswaController::class, 'storeKomentar']);
    });
});
