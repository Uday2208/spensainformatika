@extends('layouts.app')
@section('title', 'Rapor Akademik')
@section('page_title', 'Rapor & Rekapitulasi')
@section('content')

@if(session('success'))
<div class="mb-4 bg-green-100 text-green-800 p-3 rounded text-sm border border-green-200">
    {{ session('success') }}
</div>
@endif

@if($errors->any())
<div class="mb-4 bg-red-100 text-red-800 p-3 rounded text-sm border border-red-200">
    <ul class="list-disc ml-5">
        @foreach($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach
    </ul>
</div>
@endif

<div class="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
    <!-- Identitas Siswa -->
    <div class="lg:col-span-2 bg-white rounded border border-slate-200 p-4 shadow-sm flex items-center">
        <div class="w-16 h-16 rounded border border-slate-200 bg-slate-50 flex items-center justify-center text-2xl font-bold text-slate-400 mr-4">
            {{ substr(auth()->user()->name, 0, 1) }}
        </div>
        <div>
            <h2 class="text-xl font-bold text-slate-800">{{ auth()->user()->name }}</h2>
            <div class="text-sm text-slate-600 mt-1 flex gap-4">
                <span>Nomer Induk: <strong class="font-mono">{{ $siswa->nis ?? 'Tidak ditemukan' }}</strong></span>
                <span>Kelas: <strong>{{ $siswa->kelas->nama_kelas ?? 'Belum ada kelas' }}</strong></span>
            </div>
        </div>
    </div>

    <!-- Ringkasan Singkat -->
    <div class="bg-white rounded border border-slate-200 p-4 shadow-sm flex flex-col justify-center">
        @php
            $rataRata = $nilais->avg('nilai_akhir') ?? 0;
            $totalAbsen = $absensis->count();
            $hadir = $absensis->where('status', 'hadir')->count();
            $sakit = $absensis->where('status', 'sakit')->count();
            $izin = $absensis->where('status', 'izin')->count();
            $dispen = $absensis->where('status', 'dispen')->count();
            $alpha = $absensis->where('status', 'alpha')->count();
            $persentaseHadir = $totalAbsen > 0 ? ($hadir / $totalAbsen) * 100 : 0;
        @endphp
        <div class="flex justify-between items-center mb-3 pb-2 border-b border-slate-100">
            <div>
                <span class="block text-sm text-slate-600">Rata-rata Nilai:</span>
                <span class="text-[10px] font-bold {{ $rataRata >= $kkm ? 'text-green-600' : 'text-red-500' }}">
                    Status: {{ $rataRata >= $kkm ? 'TUNTAS' : 'BELUM TUNTAS' }} (KKM: {{ $kkm }})
                </span>
            </div>
            <span class="font-bold text-2xl {{ $rataRata >= $kkm ? 'text-green-600' : 'text-red-600' }}">{{ number_format($rataRata, 1) }}</span>
        </div>
        <div class="flex justify-between items-center">
            <div>
                <span class="block text-sm text-slate-600">Kehadiran ({{ number_format($persentaseHadir, 0) }}%):</span>
                <span class="text-[10px] font-medium text-slate-500">
                    H: {{ $hadir }} | S: {{ $sakit }} | I: {{ $izin }} | D: {{ $dispen }} | A: {{ $alpha }}
                </span>
            </div>
            <span class="font-bold text-2xl {{ $persentaseHadir >= 80 ? 'text-blue-600' : 'text-red-600' }}">{{ $totalAbsen }}<span class="text-xs text-slate-400 font-normal">hari</span></span>
        </div>
    </div>
</div>

<div class="bg-white rounded border border-slate-200 shadow-sm overflow-hidden" x-data="{ tab: 'nilai' }">
    <!-- Tabs -->
    <div class="flex border-b border-slate-200 bg-slate-50 overflow-x-auto">
        <button @click="tab = 'nilai'" :class="tab === 'nilai' ? 'bg-white border-b-2 border-blue-600 text-blue-700 font-bold' : 'text-slate-600 hover:bg-slate-100'" class="px-5 py-3 text-sm transition-colors whitespace-nowrap">
            Daftar Nilai
        </button>
        <button @click="tab = 'absensi'" :class="tab === 'absensi' ? 'bg-white border-b-2 border-blue-600 text-blue-700 font-bold' : 'text-slate-600 hover:bg-slate-100'" class="px-5 py-3 text-sm transition-colors border-l border-slate-200 whitespace-nowrap">
            Kehadiran
        </button>
        <button @click="tab = 'harian'" :class="tab === 'harian' ? 'bg-white border-b-2 border-blue-600 text-blue-700 font-bold' : 'text-slate-600 hover:bg-slate-100'" class="px-5 py-3 text-sm transition-colors border-l border-slate-200 whitespace-nowrap">
            Keaktifan Harian
        </button>
        <button @click="tab = 'materi'" :class="tab === 'materi' ? 'bg-white border-b-2 border-blue-600 text-blue-700 font-bold' : 'text-slate-600 hover:bg-slate-100'" class="px-5 py-3 text-sm transition-colors border-l border-slate-200 whitespace-nowrap">
            Materi Belajar
        </button>
        <button @click="tab = 'profil'" :class="tab === 'profil' ? 'bg-white border-b-2 border-blue-600 text-blue-700 font-bold' : 'text-slate-600 hover:bg-slate-100'" class="px-5 py-3 text-sm transition-colors border-l border-slate-200 whitespace-nowrap">
            Akun
        </button>
        <button @click="tab = 'testimoni'" :class="tab === 'testimoni' ? 'bg-white border-b-2 border-blue-600 text-blue-700 font-bold' : 'text-slate-600 hover:bg-slate-100'" class="px-5 py-3 text-sm transition-colors border-l border-slate-200 whitespace-nowrap">
            Testimoni
        </button>
    </div>

    <!-- Tab Nilai -->
    <div x-show="tab === 'nilai'" class="p-0">
        @if($nilais->isEmpty())
        <div class="p-8 text-center text-slate-500 italic">Belum ada nilai yang diinput oleh Guru.</div>
        @else
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse table-compact">
                <thead>
                    <tr>
                        <th class="w-12 text-center">No</th>
                        <th>Materi / Bab</th>
                        <th class="w-24 text-center">Tugas</th>
                        <th class="w-24 text-center">Quiz</th>
                        <th class="w-24 text-center">Proyek</th>
                        <th class="w-32 text-center bg-slate-100">Nilai Akhir</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($nilais as $index => $nilai)
                    <tr class="hover:bg-slate-50">
                        <td class="text-center text-slate-500">{{ $index + 1 }}</td>
                        <td class="font-bold text-slate-700">{{ $nilai->bab }}</td>
                        <td class="text-center text-slate-600">{{ $nilai->tugas == 0 ? '-' : $nilai->tugas }}</td>
                        <td class="text-center text-slate-600">{{ $nilai->quiz == 0 ? '-' : $nilai->quiz }}</td>
                        <td class="text-center text-slate-600">{{ $nilai->proyek == 0 ? '-' : $nilai->proyek }}</td>
                        <td class="text-center font-bold {{ $nilai->nilai_akhir >= $kkm ? 'text-green-700 bg-green-50' : 'text-red-700 bg-red-50' }} flex items-center justify-center space-x-2 p-2">
                            <span>{{ $nilai->nilai_akhir }}</span>
                            @if($nilai->nilai_akhir >= $kkm)
                                <span class="px-1.5 py-0.5 bg-green-200 text-green-800 text-[9px] rounded uppercase">Tuntas</span>
                            @else
                                <span class="px-1.5 py-0.5 bg-red-200 text-red-800 text-[9px] rounded uppercase">Remedial</span>
                            @endif
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        @endif
    </div>

    <!-- Tab Absensi -->
    <div x-show="tab === 'absensi'" x-cloak class="p-0">
        @if($absensis->isEmpty())
        <div class="p-8 text-center text-slate-500 italic">Belum ada data absensi.</div>
        @else
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse table-compact">
                <thead>
                    <tr>
                        <th class="w-12 text-center">No</th>
                        <th>Tanggal</th>
                        <th class="w-40 text-center">Status</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($absensis as $index => $absen)
                    <tr class="hover:bg-slate-50">
                        <td class="text-center text-slate-500">{{ $index + 1 }}</td>
                        <td class="font-medium text-slate-700">{{ \Carbon\Carbon::parse($absen->tanggal)->format('d F Y') }}</td>
                        <td class="text-center">
                            @if($absen->status == 'hadir')
                                <span class="px-2 py-1 bg-green-100 text-green-700 rounded text-xs font-bold uppercase">Hadir</span>
                            @elseif($absen->status == 'sakit')
                                <span class="px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs font-bold uppercase">Sakit</span>
                            @elseif($absen->status == 'izin')
                                <span class="px-2 py-1 bg-yellow-100 text-yellow-700 rounded text-xs font-bold uppercase">Izin</span>
                            @elseif($absen->status == 'dispen')
                                <span class="px-2 py-1 bg-purple-100 text-purple-700 rounded text-xs font-bold uppercase">Dispen</span>
                            @else
                                <span class="px-2 py-1 bg-red-100 text-red-700 rounded text-xs font-bold uppercase">Alpha</span>
                            @endif
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        @endif
    </div>

    <!-- Tab Keaktifan Harian -->
    <div x-show="tab === 'harian'" x-cloak class="p-0">
        @if($penilaianHarians->isEmpty())
        <div class="p-8 text-center text-slate-500 italic">Belum ada data nilai keaktifan harian.</div>
        @else
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse table-compact">
                <thead>
                    <tr>
                        <th class="w-12 text-center">No</th>
                        <th>Tanggal</th>
                        <th>Pertemuan</th>
                        <th class="text-center w-32">Nilai Keaktifan</th>
                        <th>Catatan</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($penilaianHarians as $index => $harian)
                    <tr class="hover:bg-slate-50">
                        <td class="text-center text-slate-500">{{ $index + 1 }}</td>
                        <td class="font-medium text-slate-700">{{ \Carbon\Carbon::parse($harian->tanggal)->format('d F Y') }}</td>
                        <td class="text-slate-600">{{ $harian->pertemuan }}</td>
                        <td class="text-center">
                            @if($harian->nilai == 90)
                                <span class="px-2 py-1 bg-green-100 text-green-700 rounded text-xs font-bold uppercase w-full block">Aktif (90)</span>
                            @elseif($harian->nilai == 80)
                                <span class="px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs font-bold uppercase w-full block">Normal (80)</span>
                            @elseif($harian->nilai == 70)
                                <span class="px-2 py-1 bg-yellow-100 text-yellow-700 rounded text-xs font-bold uppercase w-full block">Pasif (70)</span>
                            @else
                                <span class="px-2 py-1 bg-red-100 text-red-700 rounded text-xs font-bold uppercase w-full block">Tidak (60)</span>
                            @endif
                        </td>
                        <td class="text-xs text-slate-500">{{ $harian->catatan ?: '-' }}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        @endif
    </div>

    <!-- Tab Materi Belajar -->
    <div x-show="tab === 'materi'" x-cloak class="p-4 sm:p-6 bg-slate-50">
        @if(isset($materis) && $materis->isEmpty())
        <div class="bg-white rounded border border-dashed border-slate-300 p-8 text-center shadow-sm">
            <svg class="w-12 h-12 text-slate-300 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
            <p class="text-slate-500 font-medium">Belum ada materi belajar yang dibagikan guru.</p>
        </div>
        @else
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
            @foreach($materis as $materi)
            <div class="bg-white rounded border border-slate-200 shadow-sm overflow-hidden flex flex-col group hover:shadow-md transition-shadow">
                @if($materi->foto)
                    <div class="h-32 sm:h-40 w-full overflow-hidden bg-slate-100">
                        <img src="{{ asset('uploads/materi/' . $materi->foto) }}" alt="{{ $materi->judul }}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
                    </div>
                @else
                    <div class="h-32 sm:h-40 w-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center">
                        <svg class="w-12 h-12 text-white/50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"></path></svg>
                    </div>
                @endif
                
                <div class="p-4 flex flex-col flex-grow">
                    <h4 class="font-bold text-slate-800 line-clamp-2 leading-tight mb-2">{{ $materi->judul }}</h4>
                    
                    <p class="text-xs text-slate-500 mb-4 flex-grow line-clamp-3">
                        {{ $materi->deskripsi ?: 'Tidak ada deskripsi.' }}
                    </p>
                    
                    <div class="mt-auto flex flex-col gap-2 pt-3 border-t border-slate-100">
                        <span class="text-[10px] font-medium text-slate-400 flex items-center mb-1">
                            <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                            {{ $materi->created_at->diffForHumans() }}
                        </span>
                        
                        <div class="flex items-center justify-between">
                            @if($materi->file_materi)
                            <a href="{{ asset('uploads/materi/' . $materi->file_materi) }}" target="_blank" class="text-xs font-bold text-green-700 bg-green-100 hover:bg-green-200 px-3 py-1.5 rounded-full flex items-center transition-colors shadow-sm w-max">
                                <svg class="w-3 h-3 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                                Unduh File
                            </a>
                            @else
                            <span></span>
                            @endif

                            @if($materi->link)
                            <a href="{{ $materi->link }}" target="_blank" class="text-xs font-bold text-blue-600 bg-blue-50 hover:bg-blue-100 px-3 py-1.5 rounded-full flex items-center transition-colors">
                                Buka Link
                                <svg class="w-3 h-3 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path></svg>
                            </a>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
        @endif
    </div>

    <!-- Tab Profil -->
    <div x-show="tab === 'profil'" x-cloak class="p-6">
        <h3 class="font-bold text-slate-700 mb-4 border-b border-slate-100 pb-2 text-sm">Ganti Username & Password</h3>
        
        <form action="{{ url('/app/profil') }}" method="POST" class="max-w-sm space-y-4">
            @csrf
            @method('PUT')
            
            <div>
                <label class="block text-xs font-semibold text-slate-600 mb-1">Username (Untuk Login)</label>
                <input type="text" name="username" value="{{ auth()->user()->username }}" required class="input-compact w-full bg-slate-50">
                <p class="text-[10px] text-slate-400 mt-1">Defaultnya adalah Nomer Induk Anda.</p>
            </div>
            
            <div>
                <label class="block text-xs font-semibold text-slate-600 mb-1">Password Baru (Opsional)</label>
                <input type="password" name="password" placeholder="Kosongkan jika tidak ingin mengubah" class="input-compact w-full bg-slate-50">
                <p class="text-[10px] text-slate-400 mt-1">Isi minimal 4 karakter jika ingin mengganti sandi.</p>
            </div>
            
            <div class="pt-2">
                <button type="submit" class="btn-compact bg-blue-600 hover:bg-blue-700 text-white shadow-sm">Simpan Perubahan</button>
            </div>
        </form>
    </div>

    <!-- Tab Testimoni -->
    <div x-show="tab === 'testimoni'" x-cloak class="p-6">
        <h3 class="font-bold text-slate-700 mb-4 border-b border-slate-100 pb-2 text-sm">Kirim Testimoni</h3>
        
        <form action="{{ url('/app/komentar') }}" method="POST" class="max-w-xl space-y-4">
            @csrf
            
            <div>
                <label class="block text-xs font-semibold text-slate-600 mb-1">Isi Komentar</label>
                <textarea name="isi_komentar" required maxlength="300" rows="4" class="input-compact w-full bg-slate-50" placeholder="Tuliskan pengalaman atau masukan Anda di sini..."></textarea>
                <p class="text-[10px] text-slate-400 mt-1">Maksimal 300 karakter. Komentar hanya bisa dikirim 1x setiap 7 hari.</p>
            </div>
            
            <div class="flex items-center mt-2">
                <input type="checkbox" name="is_anonim" id="is_anonim" value="1" class="w-4 h-4 text-blue-600 bg-slate-100 border-slate-300 rounded focus:ring-blue-500">
                <label for="is_anonim" class="ml-2 text-sm font-medium text-slate-700">Tampilkan sebagai Anonim (sembunyikan nama saya)</label>
            </div>
            
            <div class="pt-2">
                <button type="submit" class="btn-compact bg-blue-600 hover:bg-blue-700 text-white shadow-sm">Kirim Komentar</button>
            </div>
        </form>
    </div>
</div>

@endsection
